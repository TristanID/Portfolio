SET ECHO ON
SET LINESIZE 100
SET PAGESIZE 66
Spool C:/cprg250s/unit11LabOutput.ltxt
Spool;

rem Q1

SELECT FIRST_NAME, LAST_NAME FROM rcv_Agent WHERE Agent_Level = 'III' OR Agent_Level = 'IV';

rem Q2

SELECT Tour_Description FROM rcv_Vacation_Tour WHERE Rating_Code = 'E' OR Rating_Code = 'M' AND Tour_Description = 'Paris Highlights' OR Tour_Description = 'Paris Culture Tour';

rem Q3

COLUMN Country FORMAT A13
COLUMN Dest_Description FORMAT A60

SELECT Country, Dest_Description FROM rcv_Destination WHERE Country = 'Canada' OR Country = 'United States' ORDER BY Country;

Spool off;