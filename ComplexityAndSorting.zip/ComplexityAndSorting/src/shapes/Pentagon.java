package shapes;

public class Pentagon extends AbstractShape{

	public Pentagon(double height, double side) {
		super(height);
		this.side = side;
	}
	
	public double side;
	public double area;

	@Override
	public int compareTo(AbstractShape o) {
		return Double.compare(this.getArea(), o.getArea());
	}

	@Override
	public double getVolume() {
		return (area * height) * (1.0 + 3.0);
	}

	@Override
	public double getArea() {
		return 5 * side * side * Math.tan(Math.toRadians(54)) / 4;
	}
}
