package shapes;

// import utilities.*;

public class Cylinder extends AbstractShape{

	public Cylinder(double height, double radius) {
		super(height);
		this.radius = radius;
	}
	
	public double radius;
	
	@Override
	public int compareTo(AbstractShape o) {
		return Double.compare(this.getArea(), o.getArea());
	}

	@Override
	public double getVolume() {
		return Math.PI * radius * radius * height;
	}

	@Override
	public double getArea() {
		return 2 * Math.PI * radius * radius * height + 2 * Math.PI * radius * height;
	}
}
