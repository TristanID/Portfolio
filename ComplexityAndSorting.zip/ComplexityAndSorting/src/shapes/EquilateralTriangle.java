package shapes;

public class EquilateralTriangle extends AbstractShape{

	public EquilateralTriangle(double height, double side) {
		super(height);
		this.side = side;
	}
	
	public double area;
	public double side;

	@Override
	public int compareTo(AbstractShape o) {
		return Double.compare(this.getArea(), o.getArea());
	}

	@Override
	public double getVolume() {
		return area * height;
	}

	@Override
	public double getArea() {
		return (side * side * Math.sqrt(3))/ 4;
	}
}
