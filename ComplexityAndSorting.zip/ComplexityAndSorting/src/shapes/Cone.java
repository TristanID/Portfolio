package shapes;

//import utilities.*;

public class Cone extends AbstractShape {

	public Cone(double height, double radius) {
		super(height);
		this.radius = radius;
	}
	
	public double radius;

	@Override
	public int compareTo(AbstractShape o) {
		return Double.compare(this.getArea(), o.getArea());
	}

    @Override
    public double getVolume() {
        return (1.0 / 3.0) * Math.PI * radius * radius * height;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * (radius + Math.sqrt(radius * radius + height * height));
    }
}
