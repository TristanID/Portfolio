package shapes;

public class Octagon extends AbstractShape{

	public Octagon(double height, double side) {
		super(height);
		this.side = side;
	}
	
	public double area;
	public double side;

	@Override
	public int compareTo(AbstractShape o) {
		return Double.compare(this.getArea(), o.getArea());
	}

	@Override
	public double getVolume() {
		return 2 * (1 + Math.sqrt(2)) * side * side;
	}

	@Override
	public double getArea() {
		return getArea() * height / 4;
	}
}
