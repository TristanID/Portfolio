package shapes;

// import utilities.*;

public class Pyramid extends AbstractShape{

	public Pyramid(double height, double side) {
		super(height);
		this.side = side;
	}
	
	public double side;
	
	@Override
	public int compareTo(AbstractShape o) {
		return Double.compare(this.getArea(), o.getArea());
	}

	@Override
	public double getVolume() {
		return (1.0/3.0)*side * side * height;
	}

	@Override
	public double getArea() {
		return side * side;
	}
}
