package shapes;

public class Square extends AbstractShape{

	public Square(double height, double side) {
		super(height);
		this.side = side;
	}
	
	public double side;

	@Override
	public int compareTo(AbstractShape o) {
		return Double.compare(this.getArea(), o.getArea());
	}

	@Override
	public double getVolume() {
		return (side*side)*height;
	}

	@Override
	public double getArea() {
		return side*side;
	}
}
