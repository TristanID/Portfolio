package shapes;

// import java.util.Comparator;

public abstract class AbstractShape implements Comparable<AbstractShape> {
	
    public double height;
    public double volume;
    public double area;
   
    public AbstractShape(double height) {
        this.height = height;
//        this.volume = volume;
//        this.area = area;
    }
   
    public double getHeight() {
        return height;
    }
   
    public abstract double getVolume();
   
    public abstract double getArea();
   
    // Compare height for two shapes
    @Override
    public int compareTo(AbstractShape other) {
        return Double.compare(this.height, other.getHeight());
    }
   
    // Compare area for two shapes
//    public static Comparator<AbstractShape> areaComparator = new Comparator<AbstractShape>() {
//        @Override
//        public int compare(AbstractShape shape1, AbstractShape shape2) {
//            double area1 = shape1.area;
//            double area2 = shape2.area;
//            return Double.compare(area1, area2);
//        }
//    }
//   
//    // Compare volume for two shapes
//    public static Comparator<AbstractShape> volumeComparator = new Comparator<AbstractShape>() {
//        @Override
//        public int compare(AbstractShape shape1, AbstractShape shape2) {
//            double volume1= shape1.volume;
//            double volume2 = shape2.volume;
//            return Double.compare(volume1, volume2);
//        }
//    }
}