package utilities;

import java.util.ArrayList;
import shapes.AbstractShape;

public class InsertionSort {
    public static void insertionSort(ArrayList<AbstractShape> list) {
        int length = list.size();

        for (int i = 1; i < length; i++) {
            AbstractShape key = list.get(i);
            int j = i - 1;

            while (j >= 0 && list.get(j).compareTo(key) > 0) {
                list.set(j + 1, list.get(j));
                j = j - 1;
            }

            list.set(j + 1, key);
        }
    }
}
