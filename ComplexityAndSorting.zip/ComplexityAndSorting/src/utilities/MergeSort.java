package utilities;

import java.util.ArrayList;
import shapes.AbstractShape;

public class MergeSort {
    public static void mergeSort(ArrayList<AbstractShape> list) {
        mergeSort(list, new ArrayList<>(list.size()), 0, list.size() - 1);
    }

    private static void mergeSort(ArrayList<AbstractShape> list, ArrayList<AbstractShape> temp, int leftStart, int rightEnd) {
        if (leftStart >= rightEnd) {
            return;
        }

        int middle = (leftStart + rightEnd) / 2;

        mergeSort(list, temp, leftStart, middle);
        mergeSort(list, temp, middle + 1, rightEnd);

        mergeHalves(list, temp, leftStart, rightEnd);
    }

    private static void mergeHalves(ArrayList<AbstractShape> list, ArrayList<AbstractShape> temp, int leftStart, int rightEnd) {
        int leftEnd = (rightEnd + leftStart) / 2;
        int rightStart = leftEnd + 1;

        int leftIndex = leftStart;
        int rightIndex = rightStart;
        int index = leftStart;

        while (leftIndex <= leftEnd && rightIndex <= rightEnd) {
            AbstractShape shape1 = list.get(leftIndex);
            AbstractShape shape2 = list.get(rightIndex);

            if (shape1.compareTo(shape2) <= 0) {
                temp.set(index, shape1);
                leftIndex++;
            } else {
                temp.set(index, shape2);
                rightIndex++;
            }
            index++;
        }

        for (int i = leftIndex; i <= leftEnd; i++) {
            temp.set(index, list.get(i));
            index++;
        }

        for (int i = rightIndex; i <= rightEnd; i++) {
            temp.set(index, list.get(i));
            index++;
        }

        for (int i = leftStart; i <= rightEnd; i++) {
            list.set(i, temp.get(i));
        }
    }
}

