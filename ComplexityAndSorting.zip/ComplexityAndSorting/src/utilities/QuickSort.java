package utilities;

import java.util.ArrayList;

import shapes.AbstractShape;

public class QuickSort {
    public static void quickSort(ArrayList<AbstractShape> list) {
        quickSort(list, 0, list.size() - 1);
    }

    private static void quickSort(ArrayList<AbstractShape> list, int left, int right) {
        if (left < right) {
            int pivotIndex = partition(list, left, right);

            // Recursively sort the sub-lists on both sides of the pivot
            quickSort(list, left, pivotIndex - 1);
            quickSort(list, pivotIndex + 1, right);
        }
    }

    private static int partition(ArrayList<AbstractShape> list, int left, int right) {
        AbstractShape pivot = list.get(right);
        int i = left - 1;

        for (int j = left; j < right; j++) {
            if (list.get(j).compareTo(pivot) <= 0) {
                i++;
                // Swap list[i] and list[j]
                AbstractShape temp = list.get(i);
                list.set(i, list.get(j));
                list.set(j, temp);
            }
        }

        // Swap list[i+1] and list[right] (the pivot)
        AbstractShape temp = list.get(i + 1);
        list.set(i + 1, list.get(right));
        list.set(right, temp);

        return i + 1; // Return the index of the pivot element
    }
}
