package utilities;

import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Scanner;

import shapes.AbstractShape;

public class BubbleSort {
	
	   public static void bubbleSort(ArrayList<AbstractShape> list) {
	        int length = list.size();

	        for (int i = 0; i < length; i++) {
	            for (int j = 1; j < length - i; j++) {
	                AbstractShape shape1 = list.get(j - 1);
	                AbstractShape shape2 = list.get(j);

	                if (shape1.compareTo(shape2) > 0) { // Assuming you have a compareTo method in AbstractShape
	                    // Swap shape1 and shape2 to move the larger element to the right
	                    list.set(j - 1, shape2);
	                    list.set(j, shape1);
	                }
	            }
	        }
	    }

//	   public static void main(String[] args) {
//		   Scanner scanner = new Scanner(System.in);
//        
//	        // Accepts user input to allow them to decide how many elements the array will store
//	        System.out.print("Enter the number of elements in the array: ");
//	        int n = scanner.nextInt();
//	        int[] arr = new int[n];
//	        
//	        // Accepts user input to allow them to decide on the elements of the array to be sorted
//	        System.out.println("Enter the elements of the array:");
//	
//	        // Reads an integer from the scanner and stores it in the array
//	        for (int i = 0; i < n; i++) {
//	            arr[i] = scanner.nextInt();
//	        }
//	        
//	        // Prints out the array before it is sorted
//	        System.out.println("Array before sorting: " + Arrays.toString(arr));
//	        bubbleSort(arr);
//	
//	        // Prints out the array after it is sorted
//	        System.out.println("Array after sorting: " + Arrays.toString(arr));
//	        scanner.close();
//    }
}
