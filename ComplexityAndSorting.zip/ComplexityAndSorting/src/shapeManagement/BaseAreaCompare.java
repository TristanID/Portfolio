package shapeManagement;

import java.util.Comparator;
import shapes.AbstractShape;

public class BaseAreaCompare implements Comparator<AbstractShape> {
	@Override
	public int compare(AbstractShape shape1, AbstractShape shape2) {
      double area1 = shape1.area;
      double area2 = shape2.area;
      return Double.compare(area1, area2);
	}
}
