package shapeManagement;

import java.util.Comparator;
import shapes.AbstractShape;

public class VolumeCompare implements Comparator<AbstractShape> {
	@Override
	public int compare(AbstractShape shape1, AbstractShape shape2) {
      double volume1 = shape1.volume;
      double volume2 = shape2.volume;
      return Double.compare(volume1, volume2);
	}
}
