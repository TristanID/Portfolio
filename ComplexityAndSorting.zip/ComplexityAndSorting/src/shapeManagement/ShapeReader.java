package shapeManagement;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.util.ArrayList;

import shapes.AbstractShape;
import shapes.Cone;
import shapes.Cylinder;
import shapes.EquilateralTriangle;
import shapes.Octagon;
import shapes.Pentagon;
import shapes.Pyramid;
import shapes.Square;

import utilities.BubbleSort;
import utilities.InsertionSort;
import utilities.MergeSort;
import utilities.QuickSort;
import utilities.SelectionSort;

public class ShapeReader {
	
	public static void main(String[] args) {
		
		System.out.println("Received arguments:");
		for (String arg : args) {
		    System.out.println(arg);
		}
		
		if (args.length != 3 && args.length != 4 || !args[0].equals("-f") || !args[2].equals("-t")) {
		    System.out.println("Usage: java ShapeReader -f <file_path> -t <compare_type>");
		    return;
		}
	    
	    // Assigns the file	path to a variable for later use
	    String filePath = args[1];

	    try {
//	    	BufferedReader reader = new BufferedReader(new FileReader(filePath));
	        BufferedReader reader = new BufferedReader(new FileReader(filePath));
	        String line;
	        // Creation of the ArrayList that will store the shapes to be read
	        ArrayList<AbstractShape> shapeList = new ArrayList<>();

	        while ((line = reader.readLine()) != null) {
	        	// Separate values with a comma
	            String[] parts = line.split(",");

	            if (parts.length < 2) {
	                System.out.println("Invalid input: " + line);
	                // Skip through invalid lines
	                continue;
	            }

	            // String shapeType = parts[0].trim();
	            // double parameter = Double.parseDouble(parts[1].trim());
	            
	            // The shape type is at index 1.
	            String shapeType = parts[1].trim();
	            double parameter1 = 0;
	            double parameter2 = 0;
                
                if (parts.length >= 3) {
                    parameter1 = Double.parseDouble(parts[2].trim()); // First parameter
                }

                if (parts.length >= 4) {
                    parameter2 = Double.parseDouble(parts[3].trim()); // Second parameter
                }
                
	            // Creating the appropriate shape object based on shape type
	            AbstractShape shape = null;
	            
	            // Creating instances of the shape objects
	            if (shapeType.equalsIgnoreCase("Cone")) {
	            	// Passing extracted arguments to the constructors
	            	// based on the object's shape type
	                shape = new Cone(parameter1, parameter2);
	                
	            } else if (shapeType.equalsIgnoreCase("Cylinder")) {
	                shape = new Cylinder(parameter1, parameter2);
	                
	            } else if (shapeType.equalsIgnoreCase("EquilateralTriangle")) {
	                shape = new EquilateralTriangle(parameter1, parameter2);
	                
	            } else if (shapeType.equalsIgnoreCase("Octagon")) {
	                shape = new Octagon(parameter1, parameter2);
	                
	            } else if (shapeType.equalsIgnoreCase("Pentagon")) {
	                shape = new Pentagon(parameter1, parameter2);
	                
	            } else if (shapeType.equalsIgnoreCase("Pyramid")) {
	                shape = new Pyramid(parameter1, parameter2);
	                
	            } else if (shapeType.equalsIgnoreCase("Square")) {
	                shape = new Square(parameter1, parameter2);
	            }

	            // Adding the shape object to the ArrayList
	            if (shape != null) {
	            	shapeList.add(shape);
	            }
	        }
	        
	        // Closing the resource file
	        reader.close();
	        
	        // Extract sorting algorithm from command line and invoke it        
	        if (args.length == 4) {
                String compareType = args[3].toLowerCase();
                switch (compareType) {
	        
	        	// Implementation of the created sorting algorithms
	            case "bubble":
	            	
	            	// Assign variables to calculate benchmarks in real-time
	            	long startTime = System.currentTimeMillis();
	                BubbleSort.bubbleSort(shapeList);
	                long endTime = System.currentTimeMillis();
	                long executionTime = endTime - startTime;
	                System.out.println("Bubble Sort execution time: " + executionTime + " milliseconds.");
	                break;
	                
	            case "insertion":
	            	startTime = System.currentTimeMillis();
	            	InsertionSort.insertionSort(shapeList);
	            	endTime = System.currentTimeMillis();
	                executionTime = endTime - startTime;
	                System.out.println("Insertion Sort execution time: " + executionTime + " milliseconds.");
	            	break;
	            	
	            case "merge":
	            	startTime = System.currentTimeMillis();
	            	MergeSort.mergeSort(shapeList);
	            	endTime = System.currentTimeMillis();
	            	executionTime = endTime - startTime;
	            	System.out.println("Merge Sort execution time: " + executionTime + " milliseconds.");
	            	break;
	            	
	            case "quick":
	            	startTime = System.currentTimeMillis();
	            	QuickSort.quickSort(shapeList);
	            	endTime = System.currentTimeMillis();
	            	executionTime = endTime - startTime;
	            	System.out.println("Quick Sort execution time: " + executionTime + " milliseconds.");
	            	break;
	            	
	            case "selection":
	            	startTime = System.currentTimeMillis();
	                SelectionSort.selectionSort(shapeList);
	                endTime = System.currentTimeMillis();
	            	executionTime = endTime - startTime;
	                System.out.println("Selection Sort execution time: " + executionTime + " milliseconds.");
	                break;
	                
	            default:
	            	// If an invalid sorting algorithm is occurred
	                System.out.println("Invalid compare type: " + compareType);
	                return;
	        }
	        }
	        
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
}
