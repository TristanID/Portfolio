import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.textFormat}>Header</Text>
        </View>
        <View style={styles.body}>
          <Text style={styles.para1}>Lorem ipsum dolor sit amet</Text>
          <Text style={styles.para2}>Lorem ipsum dolor sit amet</Text>
          <Text style={styles.para3}>Lorem ipsum dolor sit amet</Text>
        </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: {
    backgroundColor: 'skyblue',
    padding: 20,
  },
  textFormat: {
    fontWeight: 'bold',
  },
  body: {
    backgroundColor: 'tomato',
  }
});
