import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';

export default function App () {
  const [users, setUsers] = useState (0)

  // Rounds to the nearest value (yes it is supposed to be spelled that way)
  // const counterr = Math.floor(users / 3)

  // First argument is a callback (function), second argument is a dependency (optional)
  useEffect(() => {
    console.log('Counter has been increased')}, // console.log(counterr)
    // [counterr]
  )
  
  return (
    <View style={styles.container}>
      <Text>Data</Text>
      {/* Increases the count of users when the button is pressed */}
      {/* using `${}` allows us to display the variable as well as the text */}
      <Button title={`Increment ${users}`} onPress={() => {setUsers(users + 1)}}/>
    </View>
  )
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
})