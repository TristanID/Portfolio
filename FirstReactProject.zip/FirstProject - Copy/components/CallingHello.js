import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
import Hello from "./Hello";

export default function App() {

  return (
    <View style={styles.container}>

      <Hello name='Tristan' />

      <StatusBar backgroundColor='red' barStyle='light-content' hidden />

    </View>
  );
}