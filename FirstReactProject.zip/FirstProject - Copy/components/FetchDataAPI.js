import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function App () {
  const [users, setUsers] = useState ([])

  // First argument is a callback (function), second argument is a dependency (optional)
  useEffect(() => {
    // 'fetchUserData' is used to get data from any API or URL
    // Fetching the response in the form of JSON
    // Sets the user state using 'setUsers'
    const fetchUserData = () => {
      fetch("https://jsonplaceholder.typicode.com/users").then
      ((response) => response.json()).then((data) => setUsers(data))
      };
    // Calling the function defined above
    fetchUserData();
  },
  // Leaving the second argument empty, is also an option
  [])
  
  return (
    <View style={styles.container}>
      <Text style={styles.title}>User Data:</Text>
      {/* 'map' acts as an iterator that runs through the list of users */}
      {/* Displays the User's Email based on the 'user.id' from the specified API */}
      {users.map((user) => (<Text key = {user.id}>{user.email}</Text>))}
    </View>
  )
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    paddingBottom: 20,
  }
})