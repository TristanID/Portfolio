import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, Button, Alert } from "react-native";

export default function App() {

  return (
    <View style={styles.container}>

      {/* Adding an alert to a button */}
      <Button title='Click Me1' color='pink' onPress={() => Alert.alert("Data is not valid.")}/>

      {/* Using multiple styles to style text */}
      <Text style={[styles.size, styles.color]}>Hello world!</Text>

      {/* Adding seperate messages in a single alert to a button */}
      <Button title='Click Me2' color='dodgerblue' onPress={() => Alert.alert("Data invalid", "Email format is incorrect.")}/>

      <Text style={[styles.size, styles.color]}>Hello all!</Text>

      {/* Adding multiple functionality options after an alert is prompted */}
      <Button title='Click Me3' color='cyan' onPress={() => Alert.alert("Data invalid", "Email format is incorrect",
      [{
      text: "cancel",
      onPress:() => console.log('Cancel was pressed!')},
      {
        text: 'ok',
        onPress:() => console.log("OK was pressed!")
      }]
      )}/>

      <StatusBar backgroundColor='red' barStyle='light-content' hidden />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 40,
    paddingHorizontal: 20,
    backgroundColor: "#fff",
    // alignItems: "center",
    // justifyContent: "center",
  },
  size: {
    fontSize: 40,
    fontWeight: 'bold',
  },
  color: {
    color: 'blue'
  }
});
