import * as React from 'react';
import { StyleSheet, View, TextInput } from "react-native";
import Display from './components/Display';
import { useState } from 'react';

export default function App() {

  // Create a state for text
  // By default, it will be an empty string
  const [name, setName] = useState("")

  return (
    <View style={styles.container}>

      <TextInput placeholder='Enter Text' onChangeText={(text) => setName(text)}/>

      {/* Passing a property */}
      <Display name={name} />
      {/* or <Display /> */}
      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});