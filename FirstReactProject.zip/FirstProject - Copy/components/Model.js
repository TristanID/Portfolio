import { StatusBar } from "expo-status-bar";
import { useState } from "react";
import { StyleSheet, Text, View, Button, Modal, ActivityIndicator, Switch } from "react-native";

export default function App() {
  const [isModalVisible, setIsModalVisible] = useState(false)

  return (
    <View style={styles.container}>
      <Button
        title="Show modal" color="pink" onPress={() => setIsModalVisible(true)}/>

        <Modal visible={isModalVisible}>
          <View>
            <Text>
              Modal Content: Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores nam, hic necessitatibus nisi ullam placeat.
              </Text>
              <Button title="Hide modal" color="cyan" onPress={() => setIsModalVisible(false)}/>
          </View>
        </Modal>

      <ActivityIndicator />
      <ActivityIndicator size='large' />
      <ActivityIndicator size='large' color='blue' />
      <ActivityIndicator animating={false} />

      <Switch />

      <StatusBar backgroundColor='red' barStyle='light-content' hidden />

      {/* <Text>Hello world!</Text> */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 40,
    paddingHorizontal: 20,
    backgroundColor: "#fff",
    // alignItems: "center",
    // justifyContent: "center",
  },
  imageStyle: {
    height: 200,
    width: 200,
  }
});
