import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, Button, Pressable, Image } from "react-native";

export default function App() {
  return (
    <View style={styles.container}>
      <Button
        title="Click me!"
        color="pink"
        onPress={() => console.log("Button clicked!")}/>

      <Pressable onPress={() => console.log("Text pressed!")}>
        <Text>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores
          nam, hic necessitatibus nisi ullam placeat.
        </Text>
      </Pressable>

      <Pressable onPress={() => console.log("Image bonked!")}>
        <Image style={styles.imageStyle}
        source={require('./assets/dog-yellow-background.jpg')}/>
      </Pressable>

      <StatusBar backgroundColor='red' barStyle='light-content' hidden />

      {/* <Text>Hello world!</Text> */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 40,
    paddingHorizontal: 20,
    backgroundColor: "#fff",
    // alignItems: "center",
    // justifyContent: "center",
  },
  imageStyle: {
    height: 200,
    width: 200,
  }
});
