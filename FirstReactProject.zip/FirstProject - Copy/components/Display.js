import * as React from 'react';
import { View, Text } from 'react-native';

// Passing the property as an argument (name)
export default function Display(props) { //or {name} or {propName='Default Value'}

    // Destructuring the property
    //const {name} = props;

    // Immutability
    props.name = "Bob";

    return (
        <View>
            {/* Receiving the property (name) */}
            <Text>Hello, {}!</Text>

            {/* <Text>Hello, {name}!</Text> */}
            {/* <Text>Hello, {props.name}!</Text> */}
        </View>
    )
};

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#fff",
      alignItems: "center",
      justifyContent: "center",
    },
  });