import React, { useState } from "react";
import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, Pressable } from "react-native";

export default function App() {
  // const [num1, setnum1] = useState(50);
  // const [num2, setnum2] = useState(30);
  return (
    <View style={styles.container}>
      {/* <Text style="styles.text">{"Adding two numbers"}</Text>
            <Text>{num1 + num2}</Text>

            <Text style="styles.text">{"Subtracting two numbers"}</Text>
            <Text>{num1 - num2}</Text>

            <Text style="styles.text">{"Multiplying two numbers"}</Text>
            <Text>{num1 * num2}</Text>

            <Text style="styles.text">{"Dividing two numbers"}</Text>
            <Text>{num1 / num2}</Text> */}

      <View style={styles.answer}>
        <Pressable style={styles.bigsqr}>
          <Text style={styles.bigtext}>ANSWER</Text>
        </Pressable>
      </View>

      <View style={styles.buttonsContainer}>
        <View style={styles.buttonsRow}>
          <Pressable style={styles.sqr}>
            <Text style={styles.text}>0</Text>
          </Pressable>
          <Pressable style={styles.sqr}>
            <Text style={styles.text}>+</Text>
          </Pressable>
          <Pressable style={styles.sqr}>
            <Text style={styles.text}>-</Text>
          </Pressable>
          <Pressable style={styles.sqr}>
            <Text style={styles.text}>x</Text>
          </Pressable>
        </View>
      </View>

      <View style={styles.buttonsRow}>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>7</Text>
        </Pressable>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>8</Text>
        </Pressable>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>9</Text>
        </Pressable>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>/</Text>
        </Pressable>
      </View>

      <View style={styles.buttonsRow}>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>4</Text>
        </Pressable>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>5</Text>
        </Pressable>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>6</Text>
        </Pressable>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>.</Text>
        </Pressable>
      </View>

      <View style={styles.buttonsRow}>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>1</Text>
        </Pressable>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>2</Text>
        </Pressable>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>3</Text>
        </Pressable>
        <Pressable style={styles.sqr}>
          <Text style={styles.text}>=</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#222",
    padding: 8,
    flexDirection: "column",
    alignItems: "center",
    // flexDirection: "row",
    // justifyContent: "column-reverse",

    // justifyContent --> horizontal axis
    // alignItems --> vertical axis
  },
  buttonsContainer: {
    marginTop: 2,
  },
  buttonsRow: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
  },
  sqr: {
    backgroundColor: "#0000ff",
    width: 90,
    height: 70,
    margin: 5,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  answer: {
    marginTop: 20,
  },
  text: {
    fontSize: 20,
    color: "white",
  },
  answer: {
    marginBotton: 60,
  },
  bigsqr: {
    marginBottom: 100,
    backgroundColor: "white",
    paddingHorizontal: 150,
    paddingVertical: 20,
    borderRadius: 10,
  },
});
