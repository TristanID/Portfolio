// Creation of a resuable Header component
import { StyleSheet, View, Text } from 'react-native';

export default function Header(){
    return (
        <View style={styles.header}>
        <Text style={styles.title}>Wednesday To-Do List</Text>
        </View>
    )
}

// Styling for Header
const styles = StyleSheet.create({
    header: {
        height: 80,
        paddingTop: 40,
        backgroundColor: 'skyblue',
      },
      title: {
        textAlign: 'center',
        color: 'white',
        fontSize: 20,
        fontWeight: 'bold',
      },
})