import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, TextInput, Button } from 'react-native';
import { useState } from 'react';

export default function CreateToDoList({submitHandler}) {
    // To keep track of the value that the user is going to input
    const [text, setText] = useState('');
    // Setting value of 'text' = newly added task or "Task1"

    // 'Val' variable stores the user's input as a parameter
    const changeHandler = (val) => {
        setText(val);
    }

    return (
        <View>
            {/* Stores newly added task or "Task1" in 'val' variable */}
            <TextInput style={StyleSheet.input} placeholder='<Enter Task>' onChangeText={(val) => changeHandler(val)} />
            {/* submitHandler is defined within App.js */}
            <Button title='Add Task' color='skyblue' onPress={() => submitHandler(text)} />
        </View>
    )
}

const styles = StyleSheet.create({
    input: {
        marginBottom: 10,
        paddingHorizontal: 8,
        paddingVertical: 6,
        borderBottomWidth: 2,
        borderBottomColor: 'black'
    }
})