// Creation of a reusable To-Do List component
import { StyleSheet, Text, View, Pressable } from 'react-native';

export default function ToDoItemList({item, clickHandler}) {
    return (
        // Calling the clickHanlder function that takes 'item.'key' as an argument/parameter
        <Pressable onPress={() => clickHandler(item.key)}>
            {/* Specifying which part of 'item' to be displayed, in this case, text */}
            <Text style={styles.text}>{item.text}</Text>
        </Pressable>
    )
}

// Styling for ToDoItemList
const styles = StyleSheet.create({
    text: {
        padding: 10,
        fontSize: 16,
        // fontWeight: 'bold',
        backgroundColor: 'skyblue',
        marginTop: 10,
        // borderWidth: 1,
        borderRadius: 14,
        borderColor: 'black',
        // borderStyle: 'dashed',
      }
})