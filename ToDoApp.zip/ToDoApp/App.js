import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, FlatList, Pressable } from 'react-native';
import { useState } from 'react';
import ToDoItemList from './components/todoitemlist';
import Header from './components/header';
import CreateToDoList from './components/createToDoList';

export default function App() {
  const [task, setTask] = useState([
    // Defining keys because functions/tasks will work off of them
    {text: 'Get up at 8AM', key: 1},
    {text: 'Take a shower by 8:30AM', key: 2},
    {text: 'Prepare breakfast and grab a coffee by 9AM', key: 3},
    {text: 'Leave for school by 10AM', key: 4},
    {text: 'Prepare for CPRG-303 class from 10:30-11AM', key: 5},
    {text: 'Attend CPRG-303 lecture from 12-2PM', key: 6},
  ]);

  // Will handle events caused by clicking the To-Do List items
  const clickHandler = (key) => {
    console.log(key);
    // Takes the array as an argument
    setTask((prevTask) => {
      // Takes the key and filters out the 'accomplished' tasks that were clicked
      return prevTask.filter(task => task.key != key);
    })
  }

  const submitHandler = (text) => {
    setTask(prevToDo => {
      // Returning 'text' variable + the previous To-Do List array
      // The 'Spread' operator is how it returns the previous array
      // Generates a random number value for 'key' and converts it into a string
      return [{ text: text, key: Math.random().toString() },...prevToDo]
    })
  }

  return (
    <View style={styles.container}>

      <Header />

      <View style={styles.content}>

        <CreateToDoList submitHandler={submitHandler}/>
        
        <View style={styles.list}>
          <FlatList
          // FlatList is a used as a loop e.g., for, if, while, etc.
          data={task}
          // Iterates through each defined list of 'text' items/variables
          renderItem={({ item }) => (
            <ToDoItemList item={item} clickHandler={clickHandler} />
          )}
          />

        </View>
      </View>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eee',
    // alignItems: 'center',
    // justifyContent: 'center',
  }, 
  content: {
    padding: 12,
    // backgroundColor: 'gray',
  },
  list: {
    marginTop: 30,
  }, 
});
