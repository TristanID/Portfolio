package application;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class DateADT {
    private LocalDate date;

//	  A constructor that creates a DateADT instance based on the given year,
//    month, and day
    
    public DateADT(int year, int month, int day) {
        date = LocalDate.of(year, month, day);
    }

//    This method compares the current DateADT instance with another DateADT
    
    public int compareDates(DateADT otherDate) {
        return date.compareTo(otherDate.date);
    }

//    This method formats the DateADT instance as an ISO date string
//    (e.g., "yyyy-MM-dd")
    
    public String renderISOFormat() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return date.format(formatter);
    }

//    This method increments the date by a specified number of days
    
    public void advanceByDays(int days) {
        date = date.plusDays(days);
    }

//    This method decrements the date by a specified number of days
    
    public void retreatByDays(int days) {
        date = date.minusDays(days);
    }

//    This method finds and returns all dates in a specific year a given 
//    day name
    
    public static List<String> getDatesInYearWithDay(int year, String dayName) {
        List<String> result = new ArrayList<>();
        LocalDate currentDate = LocalDate.of(year, 1, 1);

//	  This loops through the year, checking if each date matches
//    the specified dayName
        
        while (currentDate.getYear() == year) {
            if (currentDate.getDayOfWeek().name().equalsIgnoreCase(dayName)) {
                result.add(currentDate.toString());
            }
            currentDate = currentDate.plusDays(1);
        }

        return result;
    }
}
