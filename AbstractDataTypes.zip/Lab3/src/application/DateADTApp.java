package application;

import java.util.List;

public class DateADTApp {
    public static void main(String[] args) {
//    	  This checks if the correct number of arguments are provided
    	
        if (args.length != 1) {
            System.out.println("Usage: java DateADTApp [dayName]");
            return;
        }

//        This gets the dayName from the arguments
        
        String dayName = args[0];
        int year = 2010;

//        This gets a list of dates in the specified year that match the
//        given dayName
        
        List<String> dates = DateADT.getDatesInYearWithDay(year, dayName);

//        This checks if any matching dates were found
        
        if (dates.isEmpty()) {
            System.out.println("No " + dayName + " dates found in " + year);
        } else {
        	
//        This displays the matching dates in the specified format
        	
            System.out.println("Dates in " + year + " that fall on a " + dayName + ":");
            for (String date : dates) {
                System.out.println(date);
            }
        }
    }
}
