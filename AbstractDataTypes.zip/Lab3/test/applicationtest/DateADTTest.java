package applicationtest;

import static org.junit.Assert.*;

import org.junit.Test;

import application.DateADT;

public class DateADTTest {

	@Test
//	This test compares the two dates and will pass if they are the same
//	It will fail because the result is not what was originally expected
	
	public void testCompareDates() {
		DateADT date1 = new DateADT(2022, 10, 27);
		DateADT date2 = new DateADT(2023, 11, 28);
		
		int result = date1.compareDates(date2);
		assertEquals(0, result);
	}
	
	@Test
//	This test compares an expected string to an input to be rendered
//	It will pass because the provided string and the input are the same
	
	public void testRenderISOFormat() {
		DateADT date = new DateADT(2023, 10, 27);
		String expected = "2023-10-27";
		String result = date.renderISOFormat();
		assertEquals(expected, result);
	}
	
	@Test
//	This test compares an expected string to an input plus input days
//	It will pass because the provided string and the input are the same
	
	public void testAdvanceByDays() {
		DateADT date = new DateADT(2023, 10, 27);
		date.advanceByDays(3);
		String expected = "2023-10-30";
		String result = date.renderISOFormat();
		assertEquals(expected, result);
	}
	
	@Test
//	This test compares an expected string to an input minus input days
//	It will pass because the provided string and the input are the same
	
	public void testRetreatByDays() {
		DateADT date = new DateADT(2023, 10, 27);
		date.retreatByDays(3);
		String expected = "2023-10-24";
		String result = date.renderISOFormat();
		assertEquals(expected, result);
	}

}
