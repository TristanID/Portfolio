package utilities;

import java.util.List;

public class BinarySearch {
    public static int binarySearch(List<Integer> sortedList, int target) {
        int left = 0;
        int right = sortedList.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            // Check if the middle element is equal to the target
            if (sortedList.get(mid) == target) {
                return mid; // Target found, return index
            }

            // If the target is less than the middle element, search in the left half
            if (sortedList.get(mid) > target) {
                right = mid - 1;
            } else { // If the target is greater, search in the right half
                left = mid + 1;
            }
        }

        // If the target is not found in the list, return -1
        return -1;
    }
}