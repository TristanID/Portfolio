package utilities;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BinarySearchTest {
    public static void main(String[] args) {
    	
    	// Creation of a new Array
        List<Integer> sortedList = new ArrayList<>(Arrays.asList(1, 3, 5, 7, 9, 11, 13, 15, 17));
        int target = 7;
        
        // Specify what is to be returned to the user
        int result = BinarySearch.binarySearch(sortedList, target);

        // If target is found
        if (result != -1) {
            System.out.println("Target " + target + " found at index " + result + ".");
            
        // If the target cannot be found
        } else {
            System.out.println("Target " + target + " not found in the list.");
        }
    }
}