import java.util.Comparator;

public class Student implements Comparable<Student>, Comparator<Student> {
    private String name;
    private int age;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // UsecompareTo to compare student names
    public int compareTo(Student otherStudent) {
        return this.name.compareTo(otherStudent.name);
    }

    // Use to compare student ages and names if ages are the same
    public int compare(Student student1, Student student2) {
        int ageComparison = Integer.compare(student1.age, student2.age);
        if (ageComparison == 0) {
            return student1.name.compareTo(student2.name);
        }
        return ageComparison;
    }

    // Getter methods for name and age
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    // ToString for printing Student details
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}