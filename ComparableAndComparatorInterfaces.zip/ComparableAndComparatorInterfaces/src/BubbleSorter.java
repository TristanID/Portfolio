import java.util.Arrays;
import java.util.Scanner;

public class BubbleSorter {

    public static void bubbleSort(int[] arr) {
        int length = arr.length;

        // Loop through the array elements
        for (int i = 0; i < length; i++) {
            // Iterate through the unsorted part of the array
            for (int j = 1; j < length - i; j++) {
                // Compare elements and swap them if they are in the wrong order
                if (arr[j - 1] > arr[j]) {
                    int temp = arr[j];
                    arr[j] = arr[j - 1];
                    arr[j - 1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for the number of elements in the array
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] arr = new int[n];

        // Prompt the user to enter the elements of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Display the original array
        System.out.println("Array before sorting: " + Arrays.toString(arr));

        // Sort the array using the Bubble Sort algorithm
        bubbleSort(arr);

        // Display the sorted array
        System.out.println("Array after sorting: " + Arrays.toString(arr));

        scanner.close();
    }
}