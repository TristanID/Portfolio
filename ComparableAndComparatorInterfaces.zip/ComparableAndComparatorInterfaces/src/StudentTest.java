import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StudentTest {
    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();
        students.add(new Student("Alice", 22));
        students.add(new Student("Bob", 21));
        students.add(new Student("Charlie", 20));

        System.out.println("Original list of students:");
        for (Student student : students) {
            System.out.println(student);
        }

        // Sorting by name using Comparable
        Collections.sort(students);
        System.out.println("\nSorted by name (Comparable):");
        for (Student student : students) {
            System.out.println(student);
        }

        // Sorting by age using a separate Comparator instance (lambda expression)
        Comparator<Student> ageComparator = (student1, student2) -> Integer.compare(student1.getAge(), student2.getAge());
        Collections.sort(students, ageComparator);
        System.out.println("\nSorted by age (Comparator):");
        for (Student student : students) {
            System.out.println(student);
        }
    }
}