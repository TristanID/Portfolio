/**
 * My To-Do List App
 * Tristan Idolor
 * CPRG-307
 * @format
 */

import { React, useState } from "react";
import { SafeAreaView } from "react-native";
import ToDoForm from "./components/ToDoForm";
import ToDoList from "./components/ToDoList";
import Header from "./components/Header";

export default function App() {

  // Creation of tasks using the useState hook
  // 'tasks' is the state variable holding the current list of tasks
  // 'setTasks' is the function used to update the tasks state
  const [tasks, setTasks] = useState([
    { title: 'Do the laundry', id: 1 },
    { title: "Go to the gym", id: 2 },
    { title: "Walk the dog", id: 3 }
  ]);

  // Function to add a new task to the tasks state
  // Takes 'taskText' as a parameter, representing the text of the new task
  const addTask = (taskText) => {
    // Using 'setTasks' to update the tasks state
    // Creating an array with the existing tasks and adding a new task with the provided text
    // The new task has a unique id, calculated as the length of the current tasks array plus 1
    setTasks([...tasks, { title: taskText, id: tasks.length + 1 }]);
  };

  return (
    <SafeAreaView>
      {/* Implementation of the Header.js component */}
      <Header />

      {/* Implementation of the ToDoList.js component and the corresponding tasks */}
      <ToDoList tasks={tasks} />

      {/* Implementation of the ToDoForm.js component */}
      <ToDoForm addTask={addTask} />
    </SafeAreaView>
  );
}
