import { React, useState } from "react";
import { StyleSheet, View, TextInput, Button } from "react-native";

// The form for adding new tasks
// Receives the 'addTask' function as a prop from the parent component
export default function ToDoForm({addTask}) {

  // State variable to manage the local state of the input
  const [taskText, setTaskText] = useState('');

  // Handles text input changes
  const handleInputChange = (text) => {
    setTaskText(text);
  };

  // Handles form submission
  const handleSubmit = () => {
    // Checks if 'taskText' is not empty before adding a new task
    if (taskText.trim() !== '') {
      // Calls the 'addTask' function from the parent component with the current taskText
      addTask(taskText);
      // Clears the task input
      setTaskText('');
    }
  };

  return (
    <View style={styles.form}>
      {/* TextInput for task input */}
      <TextInput
        style={styles.input}
        placeholder="Add a new task"
        onChangeText={handleInputChange}
        value={taskText}
      />
      {/* A button for submission */}
      <Button title="Add Task" onPress={handleSubmit} />
    </View>
  );
}

const styles = StyleSheet.create({
  form: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginHorizontal: 20,
    marginTop: 20,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#cccccc",
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginRight: 10,
  },
});
