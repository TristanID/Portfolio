import React from "react";
import { StyleSheet, View, Text } from "react-native";

export default function Header() {
  return (
    <View style={styles.header}>
      <Text style={styles.title}>Today's To-Do List</Text>
    </View>
  );
}

const styles = StyleSheet.create({
    header: {
        paddingTop: 40,
        marginBottom: 20,
        height: 100,
        backgroundColor: '#669999',
    },
    title: {
        textAlign: 'center',
        fontSize: 18,
        color: 'white',
    },
});