import browsing from "./browsing.webp";

export { browsing };