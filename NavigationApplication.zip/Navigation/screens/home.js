import { StatusBar } from "expo-status-bar";
import { StyleSheet, View, Text, Button } from "react-native";

export default function App ({navigation}) {
  return (
    <View style={styles.container}>
        <Text style={styles.text}>Home</Text>
        {/* onPress event navigates the user to the About page */}
        <Button title="Go to About" onPress={() => navigation.navigate("About")} />
        <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFFFFF',
        alignItems: 'center',
    },
    text: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 16,
    }
});