import { StatusBar } from "expo-status-bar";
import { StyleSheet, View, Text, Button } from "react-native";

export default function App () {
  return (
    <View style={styles.container}>
        <Text style={styles.text}>Contact Us</Text>
        <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFFFFF',
        alignItems: 'center',
    },
    text: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 16,
    }
});