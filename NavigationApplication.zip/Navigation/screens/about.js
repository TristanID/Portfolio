import { StatusBar } from "expo-status-bar";
import { StyleSheet, View, Text, Button } from "react-native";

export default function App ({route}) {
  // Stores what is taken in by 'route' inside 'name'
  const {name} = route.params;

  return (
    <View style={styles.container}>
        <Text style={styles.text}>About {name} </Text>
        {/* onPress event navigates the user to the Contact page */}
        {/* <Button title="Go to Contact" onPress={() => navigation.navigate("Contact")}/> */}
        <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFFFFF',
        alignItems: 'center',
    },
    text: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 16,
    }
});