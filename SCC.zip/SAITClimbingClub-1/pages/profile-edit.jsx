import { useState } from "react";
import { useRouter } from "next/router";
import { useSession } from "next-auth/react";

const EditProfilePage = () => {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [username, setUsername] = useState(session.user.username);
  const [email, setEmail] = useState(session.user.email);
  const [password, setPassword] = useState("");

  const handleFormSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await fetch(`/api/users/${session.user.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, email, password }),
      });
      if (response.ok) {
        // Redirect to profile page after successful update
        router.push("/profile");
      } else {
        const errorData = await response.json();
        console.error("Error updating profile:", errorData.message);
        // Handle error response
      }
    } catch (error) {
      console.error("Error updating profile:", error);
      // Handle other errors
    }
  };

  return (
    <div>
      <h1>Edit Profile</h1>
      <form onSubmit={handleFormSubmit}>
        <div>
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit">Save Changes</button>
      </form>
    </div>
  );
};

export default EditProfilePage;
