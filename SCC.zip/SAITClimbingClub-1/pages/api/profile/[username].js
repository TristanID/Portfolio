// pages/profile/[username].js

import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import { useSession } from "next-auth/react";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function getServerSideProps(context) {
  const { username } = context.params;

  // Fetch user data from the database
  const user = await prisma.user.findUnique({
    where: {
      username,
    },
  });

  return {
    props: {
      user,
    },
  };
}

const ProfilePage = ({ user }) => {
  const [formData, setFormData] = useState({
    username: user.username,
    email: user.email,
    password: "",
    newPassword: "",
  });

  const router = useRouter();
  const { data: session, status } = useSession();

  useEffect(() => {
    if (status === "authenticated") {
      // Fetch user data if user is authenticated
      fetchUserData();
    }
  }, [status]);

  const fetchUserData = async () => {
    try {
      const response = await fetch(`/api/users/${session.user.id}`);
      const userData = await response.json();
      setFormData({
        ...formData,
        username: userData.username,
        email: userData.email,
      });
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(`/api/users/${user.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: formData.email,
          password: formData.password,
          newPassword: formData.newPassword,
        }),
      });

      if (response.ok) {
        // Redirect back to the profile page
        router.push(`/profile/${user.username}`);
      } else {
        const errorData = await response.json();
        console.error("Error updating profile:", errorData.message);
        // Handle error response
      }
    } catch (error) {
      console.error("Error updating profile:", error);
      // Handle other errors
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div>
      <h1>Edit Profile</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Username:</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Current Password:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>New Password:</label>
          <input
            type="password"
            name="newPassword"
            value={formData.newPassword}
            onChange={handleChange}
          />
        </div>
        <button type="submit">Save Changes</button>
      </form>
    </div>
  );
};

export default ProfilePage;
