"use client";

import React from "react";
import { useRouter } from "next/router";
import { useSession } from "next-auth/react";

const SignUpPage = ({ event }) => {
  // Session will be undefined if no user is logged in
  const { data: session } = useSession();
  const router = useRouter();
  console.log(session);

  const signUpForEvent = async () => {
    console.log("Button clicked.");
    if (!session) {
      console.log("You must be signed in to register for an event");
      return;
    }
    // Retrieve the logged-in user's ID from the session
    const userId = session.user.id;
    const eventId = router.query.eventID;

    const response = await fetch("/api/sign-up/route", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ userId, eventId }),
    });

    if (response.ok) {
      const data = await response.json();
      console.log("Registered for event successfully");
    } else {
      const error = await response.json();
      alert(`Something went wrong: ${error.message}`);
      console.error("Failed to register for event");
    }
  };

  const handleLogout = () => {
    // Clear the isAdmin flag from localStorage
    localStorage.removeItem("isAdmin");

    // Redirect to the Login page
    router.push("/login");
  };

  return (
    <main className="min-h-screen flex flex-col">
      <div className="bg-gray-100 flex-grow">
        <h1 className="flex justify-between bg-orange-800 pt-4 pb-2 px-4 text-center text-2xl text-white font-bold">
          <button
            href="/dashboard"
            onClick={(e) => {
              e.preventDefault();
              router.push("/dashboard");
            }}
          >
            SAIT Climbing Club
          </button>
          <a
            href="/dashboard"
            className="pt-4 text-sm"
            onClick={(e) => {
              e.preventDefault();
              router.push("/dashboard");
            }}
          >
            Home
          </a>
          <a
            href="/admin"
            className="pt-4 text-sm text-black"
            onClick={(e) => {
              e.preventDefault();
              router.push("/admin");
            }}
          >
            Admin
          </a>
          <a
            href="/events"
            className="pt-4 text-sm"
            onClick={(e) => {
              e.preventDefault();
              router.push("/events");
            }}
          >
            Events
          </a>
          <button className="pt-4 text-sm" onClick={handleLogout}>
            Logout
          </button>
        </h1>
        <div className="flex flex-1 m-8">
          <div className="m-auto w-11/12">
            <div className="bg-gray-300 opacity-80 py-10 px-80">
              <div className="mx-auto w-full max-w-2xl">
                <div className="bg-gray-100 bg-opacity-80 px-20 p-4">
                  <h2 className="mt-2 text-center text-4xl p-1 font-bold leading-9 tracking-tight text-black">
                    Event Registration
                  </h2>
                </div>

                <div className="mt-20 text-center bg-gray-400 pt-4 py-6 border-2 border-orange-800">
                  <div className="event-details">
                    <h2 className="text-3xl font-bold">Event Details:</h2>
                    <h2 className="text-2xl font-bold mt-6">
                      Event Title: {event.title}
                    </h2>
                    <p className="text-lg mt-2">Event Date: {event.date}</p>
                    <p className="text-lg">Event Time: {event.time}</p>
                    <p className="text-lg font-light mt-10 pb-14">
                      "{event.description}"
                    </p>
                  </div>
                  <div>
                    <div className="flex flex-row text-white font-semibold justify-center text-xl">
                      <div className="pr-4">
                        <div className="bg-green-500 hover:bg-green-600 py-1 px-2">
                          <button onClick={signUpForEvent}>REGISTER</button>
                        </div>
                      </div>
                      <div className="pl-4">
                        <div className="bg-red-500 hover:bg-red-600 py-1 px-2">
                          <button
                            href="/events"
                            onClick={(e) => {
                              e.preventDefault();
                              router.push("/events");
                            }}
                          >
                            CANCEL
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export async function getServerSideProps(context) {
  const { query } = context;
  const eventId = query.eventID;

  const protocol = process.env.NODE_ENV === "production" ? "https" : "http";
  const host = process.env.VERCEL_URL || "localhost:3000";
  const eventRes = await fetch(
    `${protocol}://${host}/api/get-event/${eventId}`
  );

  if (!eventRes.ok) {
    console.error(
      `Failed to fetch event with ID ${eventId}: ${eventRes.status}`
    );
    return { props: { event: null, error: `Event not found` } };
  }

  const event = await eventRes.json();

  return {
    props: {
      // Passing the event details as props to the page component
      event,
    },
  };
}

export default SignUpPage;
