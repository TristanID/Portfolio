import Link from "next/link";
import { useSession } from "next-auth/react";

const ProfilePage = () => {
  const { data: session, status } = useSession();

  // If session is loading, display a loading indicator
  if (status === "loading") {
    return <div>Loading...</div>;
  }

  // If session is not loaded or user is not authenticated, prompt user to sign in
  if (!session) {
    return <div>Please sign in to view this page</div>;
  }

  // If session exists, render the profile information
  return (
    <div>
      <h1>Profile</h1>
      <p>Username: {session.user.username}</p>
      <p>Email: {session.user.email}</p>
      <Link href="/profile/edit">
        <a>Edit Profile</a>
      </Link>
    </div>
  );
};

export default ProfilePage;




