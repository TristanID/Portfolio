package exercise2;

// Class for representing nodes in the doubly-linked list
public class MyNode<E> {
	
	// The data stored in the node
	E data;
	
	// Reference to the previous node
    public MyNode<E> prev;
    
    // Reference to the next node
    public MyNode<E> next;
    public String item;

    public MyNode(E data) {
    	// Initialize the node with the given data
    	this.data = data;
    }
}