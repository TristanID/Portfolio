package exercise2;

import java.util.NoSuchElementException;

public class MyDList<E> {

    public MyNode<E> head;
    public MyNode<E> last;
    public int size;

    public MyDList() {
        head = null;
        last = null;
        size = 0;
    }

    // Adds a new element to the front of the doubly linked list
    public void addFirst(E item) {
        MyNode<E> newNode = new MyNode<>(item);
        if (isEmpty()) {
            // If the list is empty, sets both head and last to the new node
            head = newNode;
            last = newNode;
        } else {
            // Links the new node to the current head and updates head
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
        size++;
    }

    // Adds a new element to the end of the doubly linked list
    public void addLast(E item) {
        MyNode<E> newNode = new MyNode<>(item);
        if (isEmpty()) {
            // If the list is empty, sets both head and last to the new node
            head = newNode;
            last = newNode;
        } else {
            // Links the new node to the current last and updates last
            newNode.prev = last;
            last.next = newNode;
            last = newNode;
        }
        size++;
    }

    // Removes and returns the first element from the list
    public E removeFirst() {
        if (isEmpty()) {
            throw new NoSuchElementException("List is empty, cannot remove the first element.");
        }
        // Gets the data from the current head
        E item = head.data;
        // Updates head to the next node
        head = head.next;
        if (head != null) {
            head.prev = null;
        } else {
            last = null;
        }
        size--;
        return item;
    }

    // Removes and returns the last element from the list
    public E removeLast() {
        if (isEmpty()) {
            throw new NoSuchElementException("List is empty, cannot remove the last element.");
        }
        // Gets the data from the current last
        E item = last.data;
        // Updates last to the previous node
        last = last.prev;
        if (last != null) {
            last.next = null;
        } else {
            head = null;
        }
        size--;
        return item;
    }

    // Returns the current size of the list
    public int size() {
        return size;
    }

    // Checks if the list is empty
    public boolean isEmpty() {
        return size == 0;
    }
}
