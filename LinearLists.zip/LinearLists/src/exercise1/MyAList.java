package exercise1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

	public class MyAList<E> implements Iterable<E> {
		
		// ArrayList to store elements
		public ArrayList<E> data;
	
	    // Constructor to create an empty MyAList
	    public MyAList() {
	        data = new ArrayList<>();
	    }
	
	    // Adds an element to the end of the list
	    public void add(E item) {
	        data.add(item);
	    }
	
	    // Adds all elements from another MyAList to this list
	    public void addAll(MyAList<E> items) {
	        data.addAll(items.data);
	    }
	
	    // Gets an element at a specified index
	    public E get(int index) {
	        if (index < 0 || index >= data.size()) {
	            throw new IndexOutOfBoundsException("Index is out of bounds");
	        }
	        return data.get(index);
	    }
	
	    // Removes an element at a specified index
	    public void remove(int index) {
	        if (index < 0 || index >= data.size()) {
	            throw new IndexOutOfBoundsException("Index is out of bounds");
	        }
	        data.remove(index);
	    }
	
	    // Sets the element at a specified index to a new value
	    public void set(int index, E item) {
	        if (index < 0 || index >= data.size()) {
	            throw new IndexOutOfBoundsException("Index is out of bounds");
	        }
	        data.set(index, item);
	    }
	
	    // Gets the number of elements of the list
	    public int size() {
	        return data.size();
	    }
	
	    // Checks if the list is empty or not
	    public boolean isEmpty() {
	        return data.isEmpty();
	    }
	
	    // Creates an array and copies elements from the list to the array
	    public Object[] toArray() {
	        Object[] array = new Object[data.size()];
	        for (int i = 0; i < data.size(); i++) {
	            array[i] = data.get(i);
	        }
	        return array;
	    }
	
	    // Clears all elements from the list
	    public void clear() {
	        data.clear();
	    }
	
	    // Creates an iterator to traverse the elements in the list
	    public Iterator<E> iterator() {
	        return new MyAListIterator();
	    }
	
	    // Inner class for implementing the Iterator
	    private class MyAListIterator implements Iterator<E> {
	        private int currentIndex = 0;
	
	        // Checks if there is a next element to iterate
	        @Override
	        public boolean hasNext() {
	            return currentIndex < data.size();
	        }
	
	        // Gets the next element and moves to the next index
	        @Override
	        public E next() {
	            if (!hasNext()) {
	                throw new NoSuchElementException();
	            }
	            return data.get(currentIndex++);
	        }
	
	        // If Remove is not supported in this Iterator
	        @Override
	        public void remove() {
	            throw new UnsupportedOperationException("remove() is not supported");
	        }
	    }
	}
