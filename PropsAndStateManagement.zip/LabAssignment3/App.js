/**
 * My To-Do List App
 * Tristan Idolor
 * CPRG-307
 * @format
 */

import { React, useState } from "react";
import { SafeAreaView } from "react-native";
import ToDoForm from "./components/ToDoForm";
import ToDoList from "./components/ToDoList";
import Header from "./components/Header";

export default function App() {

  // Creation of tasks
  const [tasks] = useState([
    { title: 'Do the laundry', id: 1 },
    { title: "Go to the gym", id: 2 },
    { title: "Walk the dog", id: 3 }
  ]);

  return (
    <SafeAreaView>
      {/* Implementation of the Header.js component */}
      <Header />

      {/* Implementation of the ToDoList.js component and the corresponding tasks */}
      <ToDoList tasks={tasks} />

      {/* Implementation of the ToDoForm.js component */}
      <ToDoForm />
    </SafeAreaView>
  );
}
