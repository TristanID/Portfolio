Spool C:\Users\Tristan\Documents\Timber_Verification_Output.txt
Spool;
SET ECHO ON
SET FEEDBACK ON

Select * FROM Product;
Select * FROM Product_Review;
Select * FROM Customer;
Select * FROM Orders;
Select * FROM Supplier;
Select * FROM Category;
Select * FROM Sub_Category;

Spool off;