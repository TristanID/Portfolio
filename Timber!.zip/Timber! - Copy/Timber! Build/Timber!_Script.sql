Spool C:\Users\Tristan\Documents\Timber_Final_Output.txt
SET ECHO ON
SET FEEDBACK ON

DROP TABLE Product_Supplier CASCADE CONSTRAINTS;
DROP TABLE Customer_Review CASCADE CONSTRAINTS;
DROP TABLE Order_Item CASCADE CONSTRAINTS;
DROP TABLE Ship_Rate CASCADE CONSTRAINTS;
DROP TABLE Tax CASCADE CONSTRAINTS;
DROP TABLE Orders CASCADE CONSTRAINTS;
DROP TABLE Customer CASCADE CONSTRAINTS;
DROP TABLE Product_Review CASCADE CONSTRAINTS;
DROP TABLE Supplier CASCADE CONSTRAINTS;
DROP TABLE Product CASCADE CONSTRAINTS;
DROP TABLE Category CASCADE CONSTRAINTS;
DROP TABLE Sub_Category CASCADE CONSTRAINTS;

CREATE TABLE Customer
(Customer# NUMBER(10),
Customer_Firstname VARCHAR2(10) NOT NULL,
Customer_Lastname VARCHAR2(10) NOT NULL,
Customer_Phone VARCHAR2(12) NOT NULL,
Customer_Address VARCHAR2(20) NOT NULL,
Customer_City VARCHAR2(15) NOT NULL,
Customer_Province CHAR(2) NOT NULL,
Postal_code CHAR(6) NOT NULL,
Timber_member NUMBER(1) NOT NULL,
      CONSTRAINT Customer_Customer#_pk PRIMARY KEY(Customer#),
      CONSTRAINT Customer_Timber_member_ck
		CHECK (Timber_member IN (0, 1)) );

CREATE TABLE Product
(Product# NUMBER(10),
Product_Title VARCHAR2(50) NOT NULL,
Product_Description VARCHAR2(100) NOT NULL,
Product_Price NUMBER(10,2) NOT NULL,
Product_Weight NUMBER(5,2) NOT NULL,
Product_Tax NUMBER(1) NOT NULL,
Category# NUMBER(10) NOT NULL,
  	CONSTRAINT Product_Product#_pk PRIMARY KEY(Product#),
  	CONSTRAINT Product_Product_Price_ck
  		CHECK (Product_Price > 0),
  	CONSTRAINT Product_Product_Weight_ck
  		CHECK (Product_Weight > 0),
  	CONSTRAINT Product_Product_Tax_ck
  		CHECK (Product_Tax IN (0, 1)) );

CREATE TABLE Supplier
(Supplier# NUMBER(10),
Supplier_Name VARCHAR2(20) NOT NULL,
Supplier_Email VARCHAR2(20) NOT NULL,
Supplier_City VARCHAR2(20),
Supplier_Province CHAR(2),
  	CONSTRAINT Supplier_Supplier#_pk PRIMARY KEY(Supplier#),
  	CONSTRAINT Supplier_Supplier_Province_ck
  		CHECK (Supplier_Province IN ('AB', 'BC', 'SK', 'MB', 'ON', 'QC', 'NB', 'NS', 'NL', 'NT', 'NU', 'PE', 'YT')) );

CREATE TABLE Tax
(Province CHAR(2),
Province_HST NUMBER(5,3),
Province_GST NUMBER(5,3),
  	CONSTRAINT Tax_Province_pk PRIMARY KEY(Province) );

CREATE TABLE Ship_Rate
(Ship_rate# NUMBER(10),
Min_weight NUMBER(4,1),
Max_weight NUMBER(4,1),
Price NUMBER(6,2),
  	CONSTRAINT Ship_Rate_Ship_rate#_pk PRIMARY KEY(Ship_rate#),
  	CONSTRAINT Ship_rate_Max_weight_ck
  		CHECK (Max_weight >= Min_weight),
  	CONSTRAINT Ship_rate_Price_ck
  		CHECK (Price > 0) );

CREATE TABLE Order_Item
(Order# NUMBER(10),
Product# NUMBER(10),
Quantity NUMBER(3) NOT NULL,
  	CONSTRAINT Order_Item_pk PRIMARY KEY(Order#, Product#),
  	CONSTRAINT Order_Item_fk FOREIGN KEY(Product#)
  		REFERENCES Product(Product#),
  	CONSTRAINT Order_Item_Quantity_ck
  		CHECK (Quantity > 0) );

CREATE TABLE Orders
(Order# NUMBER(10),
Customer# NUMBER(10),
Order_date DATE,
Tax NUMBER(10,2),
Ship_rate# NUMBER(10) NOT NULL,
Province CHAR(2) NOT NULL,
   CONSTRAINT pk_Orders PRIMARY KEY (Order#, Customer#),
   CONSTRAINT Orders_Province_ck
           CHECK (Province IN ('AB', 'BC', 'SK', 'MB', 'ON', 'QC', 'NB', 'NS', 'NL', 'NT', 'NU', 'PE', 'YT')) );

CREATE TABLE Product_Review
(Review# NUMBER(10),
Product# NUMBER(10),
Rating NUMBER(1),
Comments VARCHAR2(1000),
  	CONSTRAINT Product_Review_Review#_pk PRIMARY KEY(Review#),
	CONSTRAINT Product_Review_Product#_fk FOREIGN KEY(Product#)
		REFERENCES Product(Product#),
  	CONSTRAINT Product_Review_Rating_ck
  		CHECK (Rating >= 1 AND Rating <= 5) );

CREATE TABLE Customer_Review
(Customer# NUMBER(10),
Review# NUMBER(10),
Date_review DATE,
  	CONSTRAINT Customer_Review_pk PRIMARY KEY(Customer#, Review#),
  	CONSTRAINT Customer_Review_Review#_fk FOREIGN KEY(Customer#)
  		REFERENCES Customer(Customer#),
  	CONSTRAINT Customer_Review_fk FOREIGN KEY(Review#)
  		REFERENCES Product_Review(Review#) );

CREATE TABLE Product_Supplier
(Product# NUMBER(10),
Supplier# NUMBER(10),
Quantity NUMBER(3),
Days_to_Deliver NUMBER(2),
  	CONSTRAINT Product_Supplier_pk PRIMARY KEY(Product#, Supplier#),
  	CONSTRAINT Product_Supplier_fk FOREIGN KEY(Product#)
  		REFERENCES Product(Product#),
  	CONSTRAINT Product_Supplier_Supplier#_fk FOREIGN KEY(Supplier#)
  		REFERENCES Supplier(Supplier#),
  	CONSTRAINT Product_Supplier_Quantity_ck
  		CHECK (Quantity >= 0),
  	CONSTRAINT Product_Supplier_Days_to_Deliver_ck
  		CHECK (Days_to_Deliver >= 0) );

CREATE TABLE Category
(Category# NUMBER(10),
    CONSTRAINT Category_category#_pk PRIMARY KEY (Category#) );

CREATE TABLE Sub_Category
(Sub_category# NUMBER(10),
Sub_category_title VARCHAR2(20) NOT NULL,
Category# NUMBER(10) NOT NULL,
Product# NUMBER(10) NOT NULL,
	CONSTRAINT Sub_Category_Sub_category#_pk PRIMARY KEY(Sub_category#),
	CONSTRAINT Sub_Category_Category#_fk FOREIGN KEY(Category#)
		REFERENCES Category(Category#) );

Describe Product;
Describe Supplier;
Describe Order_Item;
Describe Product_Review;
Describe Customer;
Describe Orders;
Describe Tax;
Describe Ship_Rate;
Describe Customer_Review;
Describe Product_Supplier;
Describe Category;
Describe Sub_Category;

Spool off;