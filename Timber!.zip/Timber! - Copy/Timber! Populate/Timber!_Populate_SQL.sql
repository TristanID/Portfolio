Spool C:\Users\Tristan\Documents\Timber_Populate_Output.txt
Spool;
SET ECHO ON
SET FEEDBACK ON

INSERT INTO Product (Product#, Product_Title, Product_Description, Product_Price, Product_Weight, Product_Tax, Category#)
VALUES (100, 'Champion Tee', 'Cotton grey tee, standard fit.', '25.81', '2.00', 0, 1);

INSERT INTO Product (Product#, Product_Title, Product_Description, Product_Price, Product_Weight, Product_Tax, Category#)
VALUES (500, 'Amazon Essentials Crewneck', 'Lightweight black sweater.', '24.70', '3.00', 0, 2);

INSERT INTO Product (Product#, Product_Title, Product_Description, Product_Price, Product_Weight, Product_Tax, Category#)
VALUES (3, 'Champion Crewneck', 'Kids fleece white pullover.', '55.90', '4.00', 0, 3);

INSERT INTO Product (Product#, Product_Title, Product_Description, Product_Price, Product_Weight, Product_Tax, Category#)
VALUES (2500, 'Amazon Essentials Beanie', 'Cuffed-knit yellow beanie.', '25.70', '1.00', 0, 4);

INSERT INTO Product (Product#, Product_Title, Product_Description, Product_Price, Product_Weight, Product_Tax, Category#)
VALUES (42369, 'Nike Mens Cross Trainer', 'Flex control TR4 running shoes.', '99.95', '5.50', 1, 5);

INSERT INTO Product (Product#, Product_Title, Product_Description, Product_Price, Product_Weight, Product_Tax, Category#)
VALUES (50, 'Champion Fleece Joggers', 'Powerblend fleece, tapered fit.', '53.34', '5.00', 0, 1);

INSERT INTO Product (Product#, Product_Title, Product_Description, Product_Price, Product_Weight, Product_Tax, Category#)
VALUES (968574, 'Nike Womens Tights', 'Sportwear essential yoga pants.', '65.26', '2.00', 0, 2);

INSERT INTO Product_Review (Review#, Product#, Rating, Comments)
VALUES (6009, 100, 5, 'Perfect for Mr.');

INSERT INTO Product_Review (Review#, Product#, Rating, Comments)
VALUES (861115, 500, 4, 'Good color and comfortable.');

INSERT INTO Product_Review (Review#, Product#, Rating, Comments)
VALUES (1649, 3, 1, 'Not sized right at all.');

INSERT INTO Product_Review (Review#, Product#, Rating, Comments)
VALUES (15, 2500, 5, 'Super warm and very thick.');

INSERT INTO Product_Review (Review#, Product#, Rating, Comments)
VALUES (0123123, 42369, 3, 'Not very shock impact-absorbing.');

INSERT INTO Customer (Customer#, Customer_Firstname, Customer_Lastname, Customer_Phone, Customer_Address, Customer_City, Customer_Province, Postal_code, Timber_member)
VALUES (150, 'Jaskaran', 'Sran', '403.805.9999', '3801 36 Street NE', 'Calgary', 'AB', 'T1Y1K3', 1);

INSERT INTO Customer (Customer#, Customer_Firstname, Customer_Lastname, Customer_Phone, Customer_Address, Customer_City, Customer_Province, Postal_code, Timber_member)
VALUES (169, 'Kevin', 'Le Huu', '403.414.9999', '6200C 36 Street NE', 'Calgary', 'AB', 'T3J0C7', 1);

INSERT INTO Customer (Customer#, Customer_Firstname, Customer_Lastname, Customer_Phone, Customer_Address, Customer_City, Customer_Province, Postal_code, Timber_member)
VALUES (190, 'Tristan', 'Idolor', '587.966.9999', '36 Street NE', 'Calgary', 'AB', 'T1Y3A9', 1);

INSERT INTO Customer (Customer#, Customer_Firstname, Customer_Lastname, Customer_Phone, Customer_Address, Customer_City, Customer_Province, Postal_code, Timber_member)
VALUES (201, 'Javkhalan', 'Baatar', '587.495.9999', '1150 Station St', 'Vancouver', 'BC', 'V6A4C7', 0);

INSERT INTO Customer (Customer#, Customer_Firstname, Customer_Lastname, Customer_Phone, Customer_Address, Customer_City, Customer_Province, Postal_code, Timber_member)
VALUES (807, 'Terrill', 'Moyo', '403.321.9999', '55 Front St W', 'Toronto', 'ON', 'M5J1E6', 0);

INSERT INTO Orders (Order#, Customer#, Order_date, Tax, Ship_rate#, Province)
VALUES (1000, 190, '21-MAR-23', '5.20', 5700, 'AB'); 

INSERT INTO Orders (Order#, Customer#, Order_date, Tax, Ship_rate#, Province)
VALUES (1001, 150, '11-MAR-23', '4.20', 430, 'AB'); 

INSERT INTO Orders (Order#, Customer#, Order_date, Tax, Ship_rate#, Province)
VALUES (1002, 169, '01-MAR-23', '2.47', 001, 'AB'); 

INSERT INTO Orders (Order#, Customer#, Order_date, Tax, Ship_rate#, Province)
VALUES (1003, 201, '08-MAR-23', '3.40', 002, 'BC');

INSERT INTO Orders (Order#, Customer#, Order_date, Tax, Ship_rate#, Province)
VALUES (1004, 807, '30-MAR-23', '3.11', 987, 'ON');

INSERT INTO Orders (Order#, Customer#, Order_date, Tax, Ship_rate#, Province)
VALUES (1005, 150, '11-MAR-23', '4.20', 430, 'AB');

INSERT INTO Orders (Order#, Customer#, Order_date, Tax, Ship_rate#, Province)
VALUES (1006, 190, '21-MAR-23', '5.20', 5700, 'AB');

INSERT INTO Supplier (Supplier#, Supplier_Name, Supplier_Email, Supplier_City, Supplier_Province)
VALUES (1, 'Amazon', 'essentials@amazon.ca', 'Toronto', 'ON');

INSERT INTO Supplier (Supplier#, Supplier_Name, Supplier_Email, Supplier_City, Supplier_Province)
VALUES (2, 'Champion', 'clothing@champion.ca', 'Calgary', 'AB');

INSERT INTO Supplier (Supplier#, Supplier_Name, Supplier_Email, Supplier_City, Supplier_Province)
VALUES (3, 'Nike', 'nike.apparel@nike.ca', 'Vancouver', 'BC');

INSERT INTO Category (Category#)
VALUES (1);

INSERT INTO Category (Category#)
VALUES (2);

INSERT INTO Category (Category#)
VALUES (3);

INSERT INTO Category (Category#)
VALUES (4);

INSERT INTO Category (Category#)
VALUES (5);

INSERT INTO Sub_category (Sub_category#, Sub_category_title, Category#, Product#)
VALUES (11, 'Mens Clothing', 1, 100);

INSERT INTO Sub_category (Sub_category#, Sub_category_title, Category#, Product#)
VALUES (12, 'Womens Clothing', 2, 500);

INSERT INTO Sub_category (Sub_category#, Sub_category_title, Category#, Product#)
VALUES (13, 'Kids Clothing', 3, 3);

INSERT INTO Sub_category (Sub_category#, Sub_category_title, Category#, Product#)
VALUES (14, 'Accessories', 4, 2500);

INSERT INTO Sub_category (Sub_category#, Sub_category_title, Category#, Product#)
VALUES (15, 'Shoes', 5, 42369);

Spool off;