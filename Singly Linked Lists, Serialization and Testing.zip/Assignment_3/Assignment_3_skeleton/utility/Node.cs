﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3_skeleton
{
    public class Node
    {
        //attributes
        private object data;
        private Node next;

        //constructors
        public Node(object data)
        {
            this.data = data;
            next = null;
        }

        public Node(object data, Node next)
        {
            this.data = data;
            this.next = next;
        }

        //public properties
        public object Data { get => data; set => data = value; }
        public Node Next { get => next; set => next = value; }
    }
}
