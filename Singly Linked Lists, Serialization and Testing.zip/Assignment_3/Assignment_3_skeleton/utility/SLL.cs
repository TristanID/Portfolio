﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Assignment_3_skeleton
{
    public class SLL : LinkedListADT  //implement linkedlist interface
    {
        //attributes
        private Node head;
        private Node tail;
        private int count;  //tracks size of list

        //public properties
        public Node Head { get => head; set => head = value; }
        public Node Tail { get => tail; set => tail = value; }
        public int Count { get => count; set => count = value; }

        //linked list empty
        public virtual bool Empty
        {
            get
            {
                return (head == null);
            }
        }

        //SLL methods
        //append method
        public void Append(object data)
        {
			count++;
			if (!Empty)
            {
                tail.Next = new Node(data);
                tail = tail.Next;
            }
            else
            {
                head = tail = new Node(data);
            }
        }

        //clear method
        public void Clear()
        {
            head = null;
            count = 0;
        }

        //contains method
        public bool Contains(object data)
        {
            Node current = head;
            while (current != null)
            {
                if (current.Data.Equals(data))
                {
                    return true;
                }
                current = current.Next;
            }
            return false;
        }

        //delete method
        public void Delete(int index)
        {
            if (index < 0 || index > count)
            {
                throw new IndexOutOfRangeException("Index is out of range.");
            }
            
            if (index == 0)
            {
                head = head.Next;
                if (head == null)
                {
                    tail = null;
                }
                count--;
                return;
            }

            Node curr = head;
            for (int i = 0; i < index - 1; i++)
            {
                curr = curr.Next;
            }
            curr.Next = curr.Next.Next;

            if (curr.Next == null)
            {
                tail = curr;
            }
            count--;
        }

        //index of method
        public int IndexOf(object data)
        {
            Node curr = head;

            for (int i = 0; i < this.count; i++)
            {
                if (curr.Data.Equals(data))
                {
                    return i;
                }
                curr = curr.Next;
            }
            return -1;
        }

        //insert method
        public void Insert(object data, int index)
        {
            if (index < 0 || index > count)  
            {
                throw new IndexOutOfRangeException();
            }
            else
            {
                Node currNode = head;
                for (int i = 0; i < index - 1; i++)
                {
                    currNode = currNode.Next;
                }
                Node aft = currNode.Next;

                Node newNode = new Node(data)
                {
                    Next = aft
                };
                currNode.Next = newNode;
            }
            count++;
        }

        //is empty method
        public bool IsEmpty()
        {
            if (head == null)
            {
                return true;
            }
            return false;
        }

        //prepend method
        public void Prepend(object data)
        {
            Node newNode = new Node(data, Head);
            if (head== null)  //if list is already empty
            {
                head = newNode;
                tail = newNode;
            }
            else
            {
                newNode.Next = head;
                head = newNode;
            }
            count++;
        }

        //replace method
        public void Replace(object data, int index)
        {
            if (index < 0 || index > count)
            {
                throw new IndexOutOfRangeException("Index out of range");
            }

            Node current = head;
            int i = 0;
            while (i < index)
            {
                current = current.Next;
                i++;
            }
            current.Data = data;
        }

        //retrieve method
        public object Retrieve(int index)
        {
            if (index < 0 || index >= count)
            {
                throw new IndexOutOfRangeException("Index is out of range.");
            }
			if (index == 0)
			{
				return head.Data;
			}
			
            int ind = 0;
			for (Node tempNode = head; tempNode != null; tempNode = tempNode.Next)
			{
				if (ind + 1 == index)
				{
					if (tempNode.Next == tail)
					{
						return tail.Data;
					}
					else
					{
						return tempNode.Next.Data;
					}
				}
				ind++;
			}
			return -1;
		}

        //size method
        public int Size()
        {
            int count = 0;
            Node current = head;

            while (current != null)
            {
                count++;
                current = current.Next;
            }
            return count;
        }


        //additional methods
        //ReverseLinkedList method
        public virtual void ReverseLinkedList()
        {
            Node predecessor_node = null;
            Node current_node = head; //Creating a new node equal to the head of the list
            Node successor_node = null;
            while (current_node != null) //While the current node index is not null
            {
                successor_node = current_node.Next;
                current_node.Next = predecessor_node;
                predecessor_node = current_node;
                current_node = successor_node;
            }
            head = predecessor_node;
        }

        //Print method
        public virtual void Print()
        {
            for (Node tempNode = Head; tempNode != null; tempNode = tempNode.Next) //Creating a new node that is equal to the head of the list
            {
                Console.WriteLine(tempNode.Data.ToString()); //To String method
            }
        }
    }
}
