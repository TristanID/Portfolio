﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

//Jas, Tristan, Kevin
//April 2, 2023
//Assignment 3 - Serialization and Testing
//Linked list interface implemtation with serialization and testing
namespace Assignment_3_skeleton
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //create new SLL linked list
            SLL linkedList = new SLL();

            //populate user objects
            User u1 = new User(1, "Joe Blow", "jblow@gmail.com", "password");
            User u2 = new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef");
            User u3 = new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555");
            User u4 = new User(4, "Ronald McDonald", "burgers4life63@outlook.com", "mcdonalds999");

            //add user objects to SLL linked list
            linkedList.Append(u1);
            linkedList.Append(u2);
            linkedList.Append(u3);
            linkedList.Append(u4);

            //binary format
            BinaryFormatter bf = new BinaryFormatter();

            SerializeObject(bf, linkedList);
            DeserializeObject(bf);

            Console.ReadKey();
        }

        //serialization
        //serialize objects method
        private static void SerializeObject(BinaryFormatter bf, SLL linkedList)
        {
            string filePath = @"user.bin";
            FileStream stream = new FileStream(filePath, FileMode.Create);

            Node current = linkedList.Head;
            while (current != null)
            {
                bf.Serialize(stream, current.Data);
                current = current.Next;
            }
            stream.Close();
        }
        
        //deserialize objects method
        private static void DeserializeObject(BinaryFormatter bf)
        {
            string filePath = @"user.bin";
            FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);

            Node current = null;
            while (stream.Position < stream.Length)
            {
                //deserialize user objects
                User linkedList = (User) bf.Deserialize(stream); 

                if(current == null)
                {
                    //print user objects
                    Console.WriteLine(linkedList.Id + "\n" + linkedList.Name + "\n" + linkedList.Email + "\n" + linkedList.Password);
                    current = new Node(linkedList);
                }
                else 
                {
                    current = current.Next = new Node(linkedList); 
                    Console.WriteLine(linkedList.Id + "\n" + linkedList.Name + "\n" + linkedList.Email + "\n" + linkedList.Password);
                }
            }
            stream.Close();
        }

    }
}
