Spool C:/Users/Tristan/Documents/UsingJoinsLab.txt
Spool;
SET ECHO ON
SET FEEDBACK ON

rem Q1
COLUMN First_name FORMAT A7
COLUMN Last_name FORMAT A6
SET PAGESIZE 70

SELECT First_name, Last_name, Tour_description, Order#, Dest_description
FROM rcv_Customer
JOIN rcv_Tour_Customer
USING (Customer_number)
JOIN rcv_Tour_Destination
USING (Tour_code)
JOIN rcv_Destination
USING (Dest_code)
JOIN rcv_Vacation_Tour
USING (Tour_code)
WHERE First_name = 'Sheldon'
AND Last_name = 'Cooper'
ORDER BY Last_name, First_name, Tour_description, Order#;

rem Q2
SELECT First_name, Last_name, Tour_description, Order#, Dest_description
FROM rcv_Customer
INNER JOIN rcv_Tour_Customer
USING (Customer_number)
INNER JOIN rcv_Tour_Destination
USING (Tour_code)
INNER JOIN rcv_Destination
USING (Dest_code)
INNER JOIN rcv_Vacation_Tour
USING (Tour_code)
WHERE First_name = 'Sheldon'
AND Last_name = 'Cooper'
ORDER BY Last_name, First_name, Tour_description, Order#;

Clear columns;

rem Q3
COLUMN First_name FORMAT A7
COLUMN Last_name FORMAT A12
SET PAGESIZE 100

SELECT DISTINCT rcv_Destination.Dest_description, rcv_Customer.First_name, rcv_Customer.Last_name
FROM rcv_Destination
LEFT JOIN rcv_Tour_Destination
ON rcv_Destination.Dest_code = rcv_Tour_Destination.Dest_code
LEFT JOIN rcv_Tour_Customer
ON rcv_Tour_Customer.Tour_code = rcv_Tour_Destination.Tour_code
LEFT JOIN rcv_Customer
ON rcv_Customer.Customer_number = rcv_Tour_Customer.Customer_number
WHERE rcv_Destination.Country = 'Canada'
ORDER BY Dest_description, First_name, Last_name;

Clear columns;

rem Q4
COLUMN Agent_ID FORMAT 9
COLUMN First_name FORMAT A7
COLUMN Last_name FORMAT A7
COLUMN Years_experience FORMAT 99
COLUMN Training_code FORMAT 9
COLUMN Agent_level FORMAT A2
SET PAGESIZE 24

SELECT * FROM rcv_Agent
NATURAL JOIN rcv_Agent_Training;

Clear columns;
Spool off;