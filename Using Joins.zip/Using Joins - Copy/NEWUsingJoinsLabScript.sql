Spool C:/Users/Tristan/Documents/UsingJoinsLab.txt
Spool;
SET ECHO ON
SET FEEDBACK ON

rem Q1
COLUMN First_name FORMAT A7
COLUMN Last_name FORMAT A6
SET PAGESIZE 70

SELECT First_name, Last_name, Tour_description, Order#, Dest_description
FROM rcv_Customer
JOIN rcv_Tour_Customer
USING (Customer_number)
JOIN rcv_Tour_Destination
USING (Tour_code)
JOIN rcv_Destination
USING (Dest_code)
JOIN rcv_Vacation_Tour
USING (Tour_code)
WHERE First_name = 'Sheldon'
AND Last_name = 'Cooper'
ORDER BY 2, 1, 3, 4;

rem Q2
SELECT c.First_name, c.Last_name, vt.Tour_description, Order#, Dest_description
FROM rcv_Customer c, rcv_Tour_Customer tc, rcv_Vacation_Tour vt, rcv_Tour_Destination td, rcv_Destination d
WHERE c.Customer_number = tc.Customer_number
AND tc.Tour_code = vt.Tour_code
AND vt.Tour_code = td.Tour_code
AND d.Dest_code = td.Dest_code
AND Last_name = 'Cooper'
ORDER BY 2, 1, 3, 4;


Clear columns;

rem Q3
COLUMN First_name FORMAT A7
COLUMN Last_name FORMAT A12
SET PAGESIZE 100

SELECT DISTINCT d.Dest_description, c.First_name, c.Last_name
FROM rcv_Customer c
JOIN rcv_Tour_Customer tc ON c.Customer_number = tc.Customer_number
JOIN rcv_Vacation_Tour vt ON vt.Tour_code = tc.Tour_code
JOIN rcv_Tour_Destination td ON td.Tour_code = vt.Tour_code
RIGHT OUTER JOIN rcv_Destination d ON d.dest_code = td.dest_code
WHERE Country = 'Canada'
ORDER BY 1, 3;

Clear columns;

rem Q4
COLUMN Agent_ID FORMAT 9
COLUMN First_name FORMAT A7
COLUMN Last_name FORMAT A7
COLUMN Years_experience FORMAT 99
COLUMN Training_code FORMAT 9
COLUMN Agent_level FORMAT A2
SET PAGESIZE 24

SELECT * FROM rcv_Agent
NATURAL JOIN rcv_Agent_Training;

Clear columns;
Spool off;