import * as THREE from 'three';
import './style.css';
import gsap from 'gsap';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls';

// Creation of scene
const scene = new THREE.Scene();

// Creation of geometric shape
const geometry = new THREE.TorusGeometry(10, 3, 16, 100); // Radius, width segments, height segments
const material = new THREE.MeshStandardMaterial({
  color: '#B0C4DE',
  roughness: 0.2,
})
const mesh = new THREE.Mesh(geometry, material); // Mesh = the combination of geometry and material
scene.add(mesh)

// Sizes
const sizes = {
  width: window.innerWidth, 
  height: window.innerHeight,
}

// Creation of light
// const light = new THREE.PointLight(0xffffff, 80, 100) //
// light.position.set(0, 10, 10) // X, Y, Z positions
// scene.add(light)

// Creation of direct light
const dirLight = new THREE.DirectionalLight(0xffffff, 1);
dirLight.position.set(-3, 10, -10);
dirLight.castShadow = true;
scene.add(dirLight);

// Creation of camera
const camera = new THREE.PerspectiveCamera(45, sizes.width / sizes.height, 0.1, 100) // Field of view, aspect ratio
camera.position.z = 50
scene.add(camera)

// Creation of renderer
const canvas = document.querySelector(".webgl");
const renderer = new THREE.WebGLRenderer({ canvas });
renderer.setSize(sizes.width, sizes.height);
renderer.setPixelRatio(window.devicePixelRatio);
renderer.setClearColor(0xffffff); // Set clear color to white
renderer.render(scene, camera);

// Creation of controls
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true
controls.enablePan = false
controls.enableZoom = false
controls.autoRotate = true
controls.autoRotateSpeed = 5

//Resize
window.addEventListener("resize", () => {
  // Update sizes
  sizes.width = window.innerWidth
  sizes.height = window.innerHeight
  // Update camera
  camera.aspect = sizes.width / sizes.height
  camera.updateProjectionMatrix()
  // Update renderer
  renderer.setSize(sizes.width, sizes.height)
})

const loop = () => {
  controls.update();
  renderer.render(scene, camera);
  window.requestAnimationFrame(loop);
}
loop()

// Timeline
const tl = gsap.timeline({ defaults: { duration: 1 }})
tl.fromTo(mesh.scale, { z:0, x:0, y:0 }, { z:1, x:1, y:1 }) // 'From' coordinates, 'To' coordinates
tl.fromTo('nav', { y:'-100%' }, { y:'0%' })
tl.fromTo('.title', { opacity: 0 }, { opacity: 1 })

// Mouse Animations
let mouseDown = false
let rgb = [];
window.addEventListener('mousedown', () => (mouseDown = true))
window.addEventListener('mouseup', () => (mouseDown = false))

window.addEventListener('mousemove', (e) => {
  if(mouseDown) {
    rgb = [
      Math.round((e.pageX / sizes.width) * 255),
      Math.round((e.pageY / sizes.height) * 255),
      150,
    ]
    let newColor = new THREE.Color(`rgb(${rgb.join(",")})`)
    gsap.to(mesh.material.color, {
      r: newColor.r,
      g: newColor.g,
      b: newColor.b
    })
  }
})