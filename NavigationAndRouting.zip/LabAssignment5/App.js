/**
 * My To-Do List App
 * Tristan Idolor
 * CPRG-307
 * @format
 */

import { React, useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import Home from "./src/screens/HomeScreen";
import About from "./src/screens/AboutScreen";

const Stack = createStackNavigator();

export default function App() {

  return (
    <NavigationContainer>
      <Stack.Navigator>

        <Stack.Screen name="Home" component={Home}
        options={{
          title:"Home Page",
          headerStyle: {backgroundColor: "skyblue"},
          headerTintColor: "white",
          headerTitleStyle: {fontWeight: "bold"}
          }}/>

        <Stack.Screen name="About" component={About}
        options={{
          title:"About Page",
          headerStyle: {backgroundColor: "skyblue"},
          headerTintColor: "white",
          headerTitleStyle: {fontWeight: "bold"}}}
        initialParams={{
          project: "'Lab Assignment 5'",
          name: "Tristan Idolor",
          date: "2023-11-16"
        }}/>

      </Stack.Navigator>
    </NavigationContainer>
  );
}
