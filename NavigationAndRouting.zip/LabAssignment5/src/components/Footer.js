import React from "react";
import { StyleSheet, View, Text } from "react-native";

export default function Footer() {
  return (
    <View style={styles.footer}>
      <Text style={styles.title}>Everyday is a Fresh Start</Text>
    </View>
  );
}

const styles = StyleSheet.create({
    footer: {
        height: 30,
        backgroundColor: 'skyblue',
    },
    title: {
        textAlign: 'center',
        fontSize: 18,
        color: 'white',
    },
});