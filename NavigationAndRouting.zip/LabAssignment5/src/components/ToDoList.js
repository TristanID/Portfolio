import React from "react";
import { StyleSheet, View, Text, FlatList } from "react-native";

// Passing the property as an argument
export default function ToDoList({tasks}) {
  
  return (

  <FlatList
  // Receiving the properties
      keyExtractor={(item) => item.id.toString()}
      data={tasks}
      renderItem={({ item }) => (
        // Setting the tasks as incomplete
          <View style={[styles.task, styles.incomplete]}>
            <Text style={styles.taskText}>{item.title}</Text>
          </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  task: {
    padding: 10,
    borderBottomWidth: 1,
    borderColor: "#cccccc",
    marginBottom: 1,
  },
  completed: {
    backgroundColor: "#b3cccc",
  },
  incomplete: {
    backgroundColor: "#cccccc",
    marginTop: 15,
    paddingHorizontal: 40,
    borderRadius: 15,
  },
  taskText: {
    fontSize: 16,
    textAlign: "center",
  },
});