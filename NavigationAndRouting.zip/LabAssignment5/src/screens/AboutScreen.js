import { React, useState } from "react";
import { StatusBar } from "expo-status-bar";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";
import MainLayout from "../layouts/MainLayout";

export default function App({ route }) {
  // Stores what is taken in by 'route' inside 'project', 'name', and 'date'
  const { project } = route.params;
  const { name } = route.params;
  const { date } = route.params;
  const [showMessage, setShowMessage] = useState(false);

  const handleNameClick = () => {
    // Function to handle click
    // Set the showMessage state to true to display the message
    setShowMessage(true);
  };

  return (
    <MainLayout>
      <View style={styles.container}>

        <Text style={styles.text1}>About the project: </Text>
        <Text style={styles.text2}>Title: {project} </Text>

        <TouchableOpacity onPress={handleNameClick}>
          <Text style={styles.text2}>By {name}</Text>
        </TouchableOpacity>

        

        <Text style={styles.text2}>Created on {date} </Text>

        {/* Display message only when showMessage state is true */}
        { showMessage && (<Text style={styles.message}>Surprise! You found the Easter egg!</Text>) }

        <StatusBar style="auto" />
      </View>
    </MainLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
  },
  text1: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 16,
    marginTop: 40,
  },
  text2: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 16,
    marginTop: 10,
  },
  message: {
    fontSize: 22,
    color: "orange",
    // Place the message at the bottom of the screen
    position: "absolute",
    bottom: 20,
  },
});
