package utilities;

import java.util.Stack;
//  import iterator for in-order traversal
import iteratorAndADT.Iterator;
//  import NoSuchElementException
import java.util.NoSuchElementException;

/**
 * 
 * @author Jaskaran Sran, Kevin Le Huu, Tristan Idolor, and Tuan Anh Nguyen
 * CPRG-304
 * Created: December 2, 2023
 * Class Description:
 * The PreOrderIterator class provides functionality to iterate over elements 
 * in a binary search tree using pre order traversal
 * It utilizes a stack to traverse through the tree nodes in the order of root, left, right
 * This iterator facilitates sequential access to elements of the tree in the
 * specified pre order sequence
 * 
 */

/**
 * An iterator for pre order traversal of a binary search tree
 * @param <E> The type of elements stored in the binary search tree
 */
public class PreOrderIterator<E extends Comparable<? super E>> implements Iterator<E> {

    // Stack to hold nodes for pre order traversal
    private Stack<BSTreeNode<E>> stack;

    /**
     * Constructs a PreOrderIterator with the root node, initializing a stack for traversal
     * @param root The root node of the binary search tree
     */
    public PreOrderIterator(BSTreeNode<E> root) {
        stack = new Stack<>();
        if (root != null) {
            stack.push(root);
        }
    }

    /**
     * Checks if the iterator has more elements to traverse
     * @return true if the iterator has more elements
     */
    @Override
    public boolean hasNext() {
        return !stack.isEmpty();
    }

    /**
     * Retrieves the next element in the pre order traversal
     * @return The next element in the iteration
     * @throws NoSuchElementException If the iteration has no more elements
     */
    @Override
    public E next() throws NoSuchElementException {
        if (!hasNext()) {
            throw new NoSuchElementException("No more elements in the iterator");
        }
        BSTreeNode<E> currentNode = stack.pop();
        if (currentNode.getRight() != null) {
            stack.push(currentNode.getRight());
        }
        if (currentNode.getLeft() != null) {
            stack.push(currentNode.getLeft());
        }
        return currentNode.getData();
    }
}
