package utilities;

import iteratorAndADT.Iterator;
//  import linked list for queue
import java.util.LinkedList;
//  import queue 
import java.util.Queue;
// import NoSuchElementException
import java.util.NoSuchElementException;

/**
 * 
 * @author Jaskaran Sran, Kevin Le Huu, Tristan Idolor, and Tuan Anh Nguyen
 * CPRG-304
 * Created: December 2, 2023
 * Class Description:
 * The PostOrderIterator class provides functionality to iterate over elements 
 * in a binary search tree using post order traversal
 * It utilizes a queue to traverse through the tree nodes in the order of left, right, root
 * This iterator facilitates sequential access to elements of the tree in the specified
 * post order sequence
 * 
 */

/**
 * An iterator for post order traversal of a binary search tree
 * @param <E> The type of elements stored in the binary search tree
 */
public class PostOrderIterator<E extends Comparable<? super E>> implements Iterator<E> {

    // Queue to hold elements for post-order traversal
    private Queue<E> queue;

    /**
     * Constructs a PostOrderIterator with the root node, initializing a queue for traversal
     * @param root The root node of the binary search tree
     */
    public PostOrderIterator(BSTreeNode<E> root) {
        queue = new LinkedList<>();
        postOrderTraversal(root);
    }

    /**
     * Recursively traverses the tree in post order and adds elements to the queue
     * @param node The current node in the traversal
     */
    private void postOrderTraversal(BSTreeNode<E> node) {
        if (node != null) {
            postOrderTraversal(node.getLeft());
            postOrderTraversal(node.getRight());
            queue.offer(node.getData());
        }
    }

    /**
     * Checks if the iterator has more elements to traverse
     * @return true if the iterator has more elements
     */
    @Override
    public boolean hasNext() {
        return !queue.isEmpty();
    }

    /**
     * Retrieves the next element in the post order traversal
     * @return The next element in the iteration
     * @throws NoSuchElementException If the iteration has no more elements
     */
    @Override
    public E next() throws NoSuchElementException {
        if (!hasNext()) {
            throw new NoSuchElementException("No more elements in the iterator");
        }
        return queue.poll();
    }
}
