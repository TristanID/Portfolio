package utilities;

import java.util.Stack;
//import iterator for in-order traversal
import iteratorAndADT.Iterator; 
//import NoSuchElementException
import java.util.NoSuchElementException;

/**
 * 
 * @author Jaskaran Sran, Kevin Le Huu, Tristan Idolor, and Tuan Anh Nguyen
 * CPRG-304
 * Created: December 2, 2023
 * Class Description:
 * An iterator for in order traversal of a binary search tree
 * This iterator implements the Iterator interface and allows iteration over
 * the elements of the binary search tree in an in order sequence
 * 
 */

/**
 * An iterator for in order traversal of a binary search tree
 * @param <E> The type of elements stored in the binary search tree
 */
public class InOrderIterator<E extends Comparable<? super E>> implements Iterator<E> {

    // Stack to hold nodes for in-order traversal
    private Stack<BSTreeNode<E>> stack;

    /**
     * Constructs an InOrderIterator with the root node, initializing a stack for traversal
     * @param root The root node of the binary search tree
     */
    public InOrderIterator(BSTreeNode<E> root) {
        stack = new Stack<>();
        pushLeftChildren(root);
    }

    /**
     * Helper method to push the left children of a node onto the stack for traversal
     * @param node The starting node to push left children from
     */
    private void pushLeftChildren(BSTreeNode<E> node) {
        while (node != null) {
            stack.push(node);
            node = node.getLeft();
        }
    }

    /**
     * Checks if the iterator has more elements to traverse
     * @return true if the iterator has more elements
     */
    @Override
    public boolean hasNext() {
        return !stack.isEmpty();
    }

    /**
     * Retrieves the next element in the in order traversal
     * @return The next element in the iteration
     * @throws NoSuchElementException If the iteration has no more elements
     */
    @Override
    public E next() throws NoSuchElementException {
        if (!hasNext()) {
            throw new NoSuchElementException("No more elements in the iterator");
        }
        BSTreeNode<E> currentNode = stack.pop();
        pushLeftChildren(currentNode.getRight());
        return currentNode.getData();
    }
}