package utilities;

/**
 * 
 * @author Jaskaran Sran, Kevin Le Huu, Tristan Idolor, and Tuan Anh Nguyen
 * CPRG-304
 * Created: December 2, 2023
 * Class Description:
 * The BSTreeNode class defines a node structure used in a binary search tree (BST)
 * It holds data, and references to the left and right child nodes
 * This class is for constructing a binary search tree data structure
 * 
 */

/**
 * Represents a node in a binary search tree
 * @param <E> The type of data stored in the node, must extend Comparable
 */
public class BSTreeNode<E extends Comparable<? super E>> {
	// Properties
    private E data;
    private BSTreeNode<E> left;
    private BSTreeNode<E> right;

    /**
     * Constructs a BSTreeNode with the given data
     * @param data The data to be stored in the node
     */
    public BSTreeNode(E data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }

    
    /**
     * Retrieves the data stored in the node
     * @return The data stored in the node
     */
    public E getData() {
        return data;
    }

    /**
     * Sets the data for the node
     * @param data The data to be set in the node
     */
    public void setData(E data) {
        this.data = data;
    }

    /**
     * Retrieves the left child node
     * @return The left child node
     */
    public BSTreeNode<E> getLeft() {
        return left;
    }

    /**
     * Sets the left child node
     * @param left The node to be set as the left child
     */
    public void setLeft(BSTreeNode<E> left) {
        this.left = left;
    }

    /**
     * Retrieves the right child node
     * @return The right child node
     */
    public BSTreeNode<E> getRight() {
        return right;
    }

    /**
     * Sets the right child node
     * @param right The node to be set as the right child
     */
    public void setRight(BSTreeNode<E> right) {
        this.right = right;
    }
}