package utilities;

import iteratorAndADT.BSTreeADT;
import iteratorAndADT.Iterator;
import exceptions.TreeException;

/**
 * 
 * @author Jaskaran Sran, Kevin Le Huu, Tristan Idolor, and Tuan Anh Nguyen
 * CPRG-304
 * Created: December 2, 2023
 * Class Description:
 * The BSTree class implements a binary search tree (BST) data structure
 * It allows operations such as insertion, deletion, searching for elements, 
 * traversing the tree in different orders (in order, pre order, post order), 
 * getting the size and height of the tree, and checking for the elements
 * within the tree
 * It also implements the BSTreeADT interface, ensuring adherence to the
 * specified BST operations
 * 
 */

/**
 * A binary search tree implementation that implements the BSTreeADT interface
 * @param <E> The type of elements stored in the binary search tree
 */
public class BSTree<E extends Comparable<? super E>> implements BSTreeADT<E> {
    private BSTreeNode<E> root;
    private int size;
 
    /**
     * Constructs an empty binary search tree
     */
    public BSTree() {
        this.root = null;
        this.size = 0;
    }
 
    /**
     * Retrieves the root node of the tree
     * It will check if the root node is empty, if it is then throw exception,
     * if not then return the root node
     * 
     * @return root The root node of the tree
     * @throws TreeException if the tree is empty
     */
    @Override
    public BSTreeNode<E> getRoot() throws TreeException {
        if (isEmpty()) {
            throw new TreeException("Tree is empty");
        }
        return root;
    }
 
    /**
     * Calculates and returns the height of the tree
     * 
     * @return The height of the tree
     */
    @Override
    public int getHeight() {
    	return calculateHeight(root);
    }
    
    /**
     * Recursive method to calculate the height of a subtree
     * @param root The node whose subtree's height is being calculated
     * @return The height of the subtree rooted at the specified node
     */
    private int calculateHeight(BSTreeNode<E> node) {
        if (node == null) {
        	// Base case: If node is null, height is 0
            return 0;
        } else {
            int leftHeight = calculateHeight(node.getLeft());
            int rightHeight = calculateHeight(node.getRight());

            // Height of the tree is the maximum of left and right subtrees + 1
            return Math.max(leftHeight, rightHeight) + 1;
        }
    }
 
    /**
     * Calculates and returns the size (number of nodes) of the tree
     * 
     * @return The size of the tree
     */
    @Override
    public int size() {
        return calculateSize(root);
    }

    /**
     * Recursive method to calculate the size of the subtree rooted at a node
     * 
     * @param root The root node of the subtree
     * @return The size of the subtree rooted at the specified node
     */
    private int calculateSize(BSTreeNode<E> node) {
        if (node == null) {
            return 0;
        }
        return 1 + calculateSize(node.getLeft()) + calculateSize(node.getRight());
    }
 
    /**
     * Checks if the tree is empty
     * 
     * @return true if the tree is empty, false otherwise
     */
    @Override
    public boolean isEmpty() {
        return root == null;
    }
 
    /**
     * This method will clear the BST by setting the root node to null
     * and the size to 0
     * This will clear the BST of any data or nodes
     */
    @Override
    public void clear() {
        root = null;
        size = 0;
    }
 
    /**
     * Checks if the tree contains a specific entry
     * This method will start at position 1 and traverse until the
     * entry contained is found
     * 
     * @param entry The entry to search for in the tree
     * @return true if the entry is found, false otherwise
     * @throws TreeException if the tree is empty
     */
    @Override
    public boolean contains(E entry) throws TreeException {
        return search(entry) != null;
    }
 
    /**
     * Searches for a specific entry in the tree
     * This method will start at position 1 and traverse until
     * the specific entry is found
     * 
     * @param entry The entry to search for
     * @return The node containing the entry if found, otherwise null
     * @throws TreeException if the tree is empty
     */
    @Override
    public BSTreeNode<E> search(E entry) throws TreeException {
        return searchHelper(root, entry);
    }
    
    /**
     * Recursive helper method to search for an entry in the tree
     * It compares the data being searched for with the data in the current
     * node (root.getData()) using the compareTo method
	 * If the data matches the data in the current node, it returns the current
	 * node (root) as it has found the entry
	 * If the data is less than the current node's data, it recursively searches
	 * in the left subtree
	 * If the data is greater than the current node's data, it recursively
	 * searches in the right subtree
	 * 
     * @param root The root of the subtree to search
     * @param data The entry to search for
     * @return The node containing the entry if found, otherwise null
     */
    private BSTreeNode<E> searchHelper(BSTreeNode<E> root, E data) {
        if (root == null) {
        	// If the tree is empty or node not found, return null
            return null;
        } else {
            int compareResult = data.compareTo(root.getData());
 
            if (compareResult == 0) {
            	// Node found, return the current root node
                return root;
            } else if (compareResult < 0) {
                // If the data is less than current node's data, search in left subtree
                return searchHelper(root.getLeft(), data);
            } else {
                // If the data is greater than current node's data, search in right subtree
                return searchHelper(root.getRight(), data);
            }
        }
    }

    /**
     * This method will add a new entry to the BST.
     * This method will create a new node with the provided newEntry data and
     * call addHelper method to insert the newNode in the BST
     * 
     * @param newEntry The entry to add
     * @return true indicating successful insertion
     * @throws NullPointerException if the newEntry is null
     */
    @Override
    public boolean add(E newEntry) throws NullPointerException {
        // Create a new node with the provided data
        BSTreeNode<E> newNode = new BSTreeNode<>(newEntry);
        // Call the helper method to perform the insertion
        root = addHelper(root, newNode);
        // Return true indicating successful insertion
        return true;
    }
 
    /**
     * Recursive helper method for inserting a new node into the BST
     * newNode.getData() retrieves the data stored in the new node
     * root.getData() retrieves the data stored in the current root node
     * 
     * @param root The root of the subtree where the insertion occurs
     * @param newNode The new node to be inserted
     * @return The updated root of the subtree
     */
    private BSTreeNode<E> addHelper(BSTreeNode<E> root, BSTreeNode<E> newNode) {
        if (root == null) {
            // If the root is null, assign the new node as the root
            return newNode;
        }
 
        // Compare data of the new node with the current root node
        int compareResult = newNode.getData().compareTo(root.getData());
 
        // If newNode.getData() is less than root.getData(), compareTo returns a negative integer
        // If newNode.getData() is greater than root.getData(), compareTo returns a positive integer
        // If newNode.getData() is equal to root.getData(), compareTo returns 0
        if (compareResult < 0) {
            // If new data is less than root data, go left
            root.setLeft(addHelper(root.getLeft(), newNode));
        } else if (compareResult > 0) {
            // If new data is greater than root data, go right
            root.setRight(addHelper(root.getRight(), newNode));
        }
 
        // Return the updated root
        return root;
    }
 
    /**
     * Returns an iterator that performs an in order traversal of the tree
     * The in order traversal visits the left subtree, then the current node,
     * and finally the right subtree
     * @return Iterator for in order traversal
     */
    @Override
    public Iterator<E> inorderIterator() {
        return new InOrderIterator<E>(root); 
    }
    
    /**
     * Returns an iterator that performs a pre order traversal of the tree
     * @return Iterator for pre order traversal
     */
    @Override
    public Iterator<E> preorderIterator() {
        return new PreOrderIterator<E>(root); 
    }
 
    /**
     * Returns an iterator that performs a postorder traversal of the tree
     * @return Iterator for postorder traversal
     */
    @Override
    public Iterator<E> postorderIterator() {
        return new PostOrderIterator<E>(root);
    }
    
    /**
     * Removes a node with the specified data from the tree
     *
     * @param data The data to be removed from the tree
     * @return true if the element was successfully removed, false otherwise
     */
    public boolean remove(E data) {
        BSTreeNode<E> parent = null;
        BSTreeNode<E> current = root;
        boolean isLeftChild = false;

        // Find the node to be removed
        while (current != null && !current.getData().equals(data)) {
            parent = current;
            int comparison = data.compareTo(current.getData());

            if (comparison < 0) {
                current = current.getLeft();
                isLeftChild = true;
            } else {
                current = current.getRight();
                isLeftChild = false;
            }
        }

        if (current == null) {
            // Node with specified data not found
            return false;
        }

        // If the node to be removed has no children
        if (current.getLeft() == null && current.getRight() == null) {
            if (current == root) {
                root = null;
            } else if (isLeftChild) {
                parent.setLeft(null);
            } else {
                parent.setRight(null);
            }
        }
        // If the node to be removed has only one child
        else if (current.getRight() == null) {
            if (current == root) {
                root = current.getLeft();
            } else if (isLeftChild) {
                parent.setLeft(current.getLeft());
            } else {
                parent.setRight(current.getLeft());
            }
        } else if (current.getLeft() == null) {
            if (current == root) {
                root = current.getRight();
            } else if (isLeftChild) {
                parent.setLeft(current.getRight());
            } else {
                parent.setRight(current.getRight());
            }
        }
        // If the node to be removed has two children
        else {
            BSTreeNode<E> successor = getSuccessor(current);

            if (current == root) {
                root = successor;
            } else if (isLeftChild) {
                parent.setLeft(successor);
            } else {
                parent.setRight(successor);
            }

            successor.setLeft(current.getLeft());
        }

        size--;
        return true;
    }

    /**
     * Gets the successor of a node in the tree
     * The successor is the smallest node in the right subtree of the given node
     *
     * @param node The node for which to find the successor
     * @return The successor node
     */
    private BSTreeNode<E> getSuccessor(BSTreeNode<E> node) {
        BSTreeNode<E> successorParent = node;
        BSTreeNode<E> successor = node;
        BSTreeNode<E> current = node.getRight();

        while (current != null) {
            successorParent = successor;
            successor = current;
            current = current.getLeft();
        }

        if (successor != node.getRight()) {
            successorParent.setLeft(successor.getRight());
            successor.setRight(node.getRight());
        }

        return successor;
    }

}