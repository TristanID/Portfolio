package exceptions;

/**
 * This exception class extends the Java Exception class and is used to handle 
 * exceptions specific to tree related operations
 * @author Jaskaran Sran, Kevin Le Huu, Tristan Idolor, and Tuan Anh Nguyen
 * Created: December 2, 2023
 * Class Description:
 * The TreeException class defines a custom exception that can be thrown to handle 
 * various exceptional scenarios encountered during tree operations
 * It encapsulates an error message related to the tree operation that caused the exception
 */

public class TreeException extends Exception {
    
	/**
     * Constructs a TreeException with the specified error message
     * @param message The error message describing the exception
     */
    public TreeException(String message) {
        super(message);
    }
}
