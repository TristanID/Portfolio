package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import iteratorAndADT.Iterator;
import utilities.BSTreeNode;
import utilities.InOrderIterator;

/**
 * 
 * @author Jaskaran Sran, Kevin Le Huu, Tristan Idolor, and Tuan Anh Nguyen
 * CPRG-304
 * Created: December 2, 2023
 * Class Description:
 * JUnit test class for the InOrderIterator class
 * This class includes tests to check the functionality of the class in returning
 * elements in the correct order during an in order traversal of a binary search tree
 * It compares the values from the iterator with the expected values
 * 
 */

public class InOrderIteratorTest {

    private BSTreeNode<Integer> root;

    /**
     * Sets up a sample binary search tree before each test case
     */
    @BeforeEach
    void setUp() {
        // Create a sample binary search tree
        root = new BSTreeNode<>(10);
        root.setLeft(new BSTreeNode<>(5));
        root.setRight(new BSTreeNode<>(15));
        root.getLeft().setLeft(new BSTreeNode<>(3));
        root.getLeft().setRight(new BSTreeNode<>(7));
        root.getRight().setLeft(new BSTreeNode<>(12));
        root.getRight().setRight(new BSTreeNode<>(20));
    }

    /**
     * Test method to verify the functionality of the InOrderIterator
     * It ensures that the InOrderIterator produces elements in the correct order
     * during an in-order traversal of the binary search tree
     * It compares the values obtained from the iterator with the expected values
     */
    @Test
    void testInOrderIterator() {
        InOrderIterator<Integer> iterator = new InOrderIterator<>(root);

        int[] expectedOrder = {3, 5, 7, 10, 12, 15, 20};
        int index = 0;

        while (iterator.hasNext()) {
            int currentValue = iterator.next();
            assertEquals(expectedOrder[index], currentValue);
            index++;
        }
    }
}