package tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import exceptions.TreeException;
import utilities.BSTree;
import utilities.PreOrderIterator;

import java.util.NoSuchElementException;

/**
 * 
 * @author Jaskaran Sran, Kevin Le Huu, Tristan Idolor, and Tuan Anh Nguyen
 * CPRG-304
 * Created: December 2, 2023
 * Class Description:
 * JUnit test class for the PreOrderIterator class
 * This class includes tests to verify the functionality of the class in returning
 * elements in the correct order during a pre order traversal of a binary search tree
 * It checks if the values obtained from the iterator match the expected values
 * It also checks if the iterator throws NoSuchElementException
 * 
 */

public class PreOrderIteratorTest {

    private BSTree<Integer> bst;

    /**
     * Sets up a sample Binary Search Tree before each test case
     */
    @BeforeEach
    void setUp() {
        // Creating a sample Binary Search Tree
        bst = new BSTree<>();
        bst.add(5);
        bst.add(3);
        bst.add(7);
        bst.add(2);
        bst.add(4);
        bst.add(6);
        bst.add(8);
    }

    /**
     * Test method to verify the functionality of the PreOrderIterator
     * It checks if the PreOrderIterator produces elements in the correct order
     * during a pre-order traversal of the binary search tree
     * It compares the values obtained from the iterator with the expected values
     * It also verifies that the iterator throws NoSuchElementException appropriately
     * @throws TreeException if an issue occurs with the tree structure
     */
    @Test
    void testPreOrderTraversal() throws TreeException {
        PreOrderIterator<Integer> iterator = new PreOrderIterator<>(bst.getRoot());

        // Expected order based on pre-order traversal of the tree
        Integer[] expected = { 5, 3, 2, 4, 7, 6, 8 };

        for (Integer value : expected) {
            assertTrue(iterator.hasNext());
            assertEquals(value, iterator.next());
        }

        assertFalse(iterator.hasNext());

        // Verify NoSuchElementException is thrown when attempting to retrieve more elements
        assertThrows(NoSuchElementException.class, iterator::next);
    }
}
