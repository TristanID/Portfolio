package tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import utilities.BSTreeNode;
import utilities.PostOrderIterator;

/**
 * 
 * @author Jaskaran Sran, Kevin Le Huu, Tristan Idolor, and Tuan Anh Nguyen
 * CPRG-304
 * Created: December 2, 2023
 * Class Description:
 * Unit tests for the PostOrderIterator class
 * The test cases ensure the correct functionality of the PostOrderIterator 
 * during post order traversal of a binary search tree
 * 
 */

/**
 * 
 * Test scenarios are:
 * Instantiating a binary search tree for testing purposes
 * Verifying the accuracy of the post-order traversal sequence
 *
 */
class PostOrderIteratorTest {

    private BSTreeNode<Integer> root;

    /**
     * Sets up the binary search tree for each test case
     * Creates nodes representing a binary search tree structure for testing purposes
     */
    @BeforeEach
    void setUp() {
        /*
         *          10
         *         /  \
         *        5    15
         *       / \   / \
         *      3   7 12 20
         */
    	
    	root = new BSTreeNode<>(10);
    	root.setLeft(new BSTreeNode<>(5));
    	root.setRight(new BSTreeNode<>(15));
    	root.getLeft().setLeft(new BSTreeNode<>(3));
    	root.getLeft().setRight(new BSTreeNode<>(7));
    	root.getRight().setLeft(new BSTreeNode<>(12));
    	root.getRight().setRight(new BSTreeNode<>(20));
    }

    /**
     * Tests the functionality of the PostOrderIterator class
     * Verifies the correctness of the post-order traversal sequence
     */
    @Test
    void testPostOrderIterator() {
        PostOrderIterator<Integer> iterator = new PostOrderIterator<>(root);
        // Expected post order traversal sequence: 3, 7, 5, 12, 20, 15, 10

        assertEquals(Integer.valueOf(3), iterator.next());
        assertEquals(Integer.valueOf(7), iterator.next());
        assertEquals(Integer.valueOf(5), iterator.next());
        assertEquals(Integer.valueOf(12), iterator.next());
        assertEquals(Integer.valueOf(20), iterator.next());
        assertEquals(Integer.valueOf(15), iterator.next());
        assertEquals(Integer.valueOf(10), iterator.next());
        assertFalse(iterator.hasNext());
    }
}
