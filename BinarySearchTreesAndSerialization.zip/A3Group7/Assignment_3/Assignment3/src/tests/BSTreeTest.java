package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import exceptions.TreeException;
import iteratorAndADT.BSTreeADT;
import utilities.BSTree;
import utilities.BSTreeNode;

/**
 * 
 * @author Jaskaran Sran, Kevin Le Huu, Tristan Idolor, and Tuan Anh Nguyen
 * CPRG-304
 * Created: December 2, 2023
 * Class Description:
 * Test class for the BSTree implementation
 * It tests various methods and functionalities of the BSTree class
 * 
 */

class BSTreeTest {
	
	private static BSTree<Integer> bst;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterAll
	static void tearDownAfterClass() throws Exception {
		bst = null;
	}

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		// Create a new instance of your Binary Search Tree before each test
        bst = new BSTree<>(); // Instantiate your BST implementation
        // Add elements to the tree for testing purposes
        bst.add(5);
        bst.add(3);
        bst.add(7);
        bst.add(2);
        bst.add(4);
        bst.add(6);
        bst.add(8);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link iteratorAndADT.BSTreeADT#getRoot()}.
	 * @throws TreeException 
	 */
	@Test
	void testGetRoot() throws TreeException {
		assertEquals(Integer.valueOf(5), bst.getRoot().getData());
        // Assuming your getRoot() method returns the root node of the tree,
        // verify that the data at the root node is as expected
	}

	/**
	 * Test method for {@link iteratorAndADT.BSTreeADT#getHeight()}.
	 */
	@Test
	void testGetHeight() {
		assertEquals(3, bst.getHeight());
        // Check if the height of the tree matches the expected height
        // based on the elements added in the setUp() method
	}

	/**
	 * Test method for {@link iteratorAndADT.BSTreeADT#size()}.
	 */
	@Test
	void testSize() {
		assertEquals(7, bst.size());
        // Verify that the size of the tree matches the number of elements added
	}

	/**
	 * Test method for {@link iteratorAndADT.BSTreeADT#isEmpty()}.
	 */
	@Test
    void testIsEmptyEmptyTree() {
        BSTree<Integer> emptyTree = new BSTree<>();
        assertTrue(emptyTree.isEmpty());
        // Verify that a newly created tree without elements is empty
    }

    @Test
    void testIsEmptyNonEmptyTree() {
        assertFalse(bst.isEmpty());
        // Verify that the tree created in setUp() with added elements is not empty
    }

    @Test
    void testIsEmptyAfterClear() {
        bst.clear();
        assertTrue(bst.isEmpty());
        // Verify that the tree becomes empty after clearing it
    }

	/**
	 * Test method for {@link iteratorAndADT.BSTreeADT#clear()}.
	 */
	@Test
	void testClear() {
		bst.clear();
        assertTrue(bst.isEmpty());
        assertEquals(0, bst.size());
        // After clearing the tree, it should be empty with size 0
	}

	/**
	 * Test method for {@link iteratorAndADT.BSTreeADT#contains(java.lang.Comparable)}.
	 * @throws TreeException 
	 */
	@Test
	void testContains() throws TreeException {
		assertTrue(bst.contains(3));
        assertTrue(bst.contains(7));
        assertFalse(bst.contains(9));
        // Test if certain elements are present or not in the tree
	}

	/**
	 * Test method for {@link iteratorAndADT.BSTreeADT#search(java.lang.Comparable)}.
	 */
	@Test
	void testSearch() throws TreeException {
	    // Create a new instance of your Binary Search Tree
	    BSTree<Integer> bst = new BSTree<>();
	    
	    // Add elements to the tree
	    bst.add(5);
	    bst.add(3);
	    bst.add(7);

	    // Search for elements that should exist in the tree
	    BSTreeNode<Integer> foundNode1 = bst.search(3);

	    // Search for an element that doesn't exist in the tree
	    BSTreeNode<Integer> notFoundNode = bst.search(9);

	    // Verify that the found nodes are not null (i.e., they exist in the tree)
	    assertNotNull(foundNode1);

	    // Verify that the node that shouldn't exist is null
	    assertNull(notFoundNode);

	    // Optionally, you can further validate the data within the found nodes
	    assertEquals(Integer.valueOf(3), foundNode1.getData());
	}

	/**
	 * Test method for {@link iteratorAndADT.BSTreeADT#add(java.lang.Comparable)}.
	 */
	@Test
	void testAdd() throws TreeException {
	    // Create a new instance of your Binary Search Tree
	    BSTree<Integer> bst = new BSTree<>();
	    
	    // Add elements to the tree
	    bst.add(5);
	    bst.add(3);

	    // Check if the elements added are present in the tree
	    assertTrue(bst.contains(5));
	    assertTrue(bst.contains(3));

	    // Add a new element to the tree
	    bst.add(9);

	    // Check if the newly added element is present in the tree
	    assertTrue(bst.contains(9));
	}
	
	/**
	 * Removes the specified element from the binary search tree if it is present.
	 * If the element is found and removed, the tree's structure is adjusted accordingly.
	 * If the element is not present, no changes are made to the tree.
	 *
	 * @param element the element to be removed from the tree
	 * @throws TreeException if the tree is empty or the element is null
	 */
	@Test
	void testRemove() throws TreeException {
	    // Creating a new instance of the Binary Search Tree
	    BSTree<Integer> bst = new BSTree<>();
	    
	    // Add elements to the tree
	    bst.add(5);
	    bst.add(3);
	    bst.add(7);

	    // Check if the elements were added to the BST
	    assertTrue(bst.contains(3));
	    assertTrue(bst.contains(7));

	    // Remove elements
	    bst.remove(3);
	    bst.remove(7);

	    // Check if the elements were removed from the BST
	    assertFalse(bst.contains(3));
	    assertFalse(bst.contains(7));
	}
}
