// Header component

import React from 'react';

function Header({ headerText }) {
  return (
    <header style={{ position: 'fixed', top: 0, left: 0, right: 0, backgroundColor: '#082F49', color: '#FFFFFF'}} className="py-2 text-center">
      <p>{headerText}</p>
    </header>
  );
}

export default Header;