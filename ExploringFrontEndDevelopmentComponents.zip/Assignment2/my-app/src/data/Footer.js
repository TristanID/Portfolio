// Footer component

import React from 'react';

function Footer({ footerText }) {
  return (
    <footer style={{ position: 'fixed', bottom: 0, left: 0, right: 0, backgroundColor: '#082F49', color: '#FFFFFF'}} className="py-2 text-center">
      <p>{footerText}</p>
    </footer>
  );
}

export default Footer;
