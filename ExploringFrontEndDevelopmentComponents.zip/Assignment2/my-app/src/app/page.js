/* Group 1: Exploring Front-End Development Components
* Tristan Idolor, Jaskaran Sran, Kevin Le Huu, Harsingh Sekhon and Troy Franks
* Submission Date: 10-30-2023
*
* This program replicates a high school registration form for new students at New Generation High School
and includes the functionality of being able to view the currently enrolled students for the 2023 year */

"use client";
import StudentDatabase from '@/components/StudentDatabase';
import Header from '../data/Header';
import Footer from '../data/Footer';

export default function Home() {
  // Implementation of Header.js and setting the header text
  const MyHeaderText = "NGHS Student List"
  // Implementation of Footer.js and setting the footer text
  const MyFooterText = "New Generation High School | NGHS | Est. 2023"

  return (
    <main className="flex min-h-screen flex-col bg-sky-700 mx-auto">
      {/* <main className="flex min-h-screen flex-col items-center justify-between p-14 bg-sky-600"> */}
      <Header headerText={MyHeaderText}/>
      {/* Implementation of StudentDatabase.jsx */}
      <StudentDatabase />
      <Footer footerText={MyFooterText}/>
    </main>
  )
}