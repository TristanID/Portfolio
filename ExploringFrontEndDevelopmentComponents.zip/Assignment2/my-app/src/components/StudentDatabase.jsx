"use client";
import React from "react";
import { useEffect, useState } from "react";

const StudentDatabase = () => {
  const [students, setStudents] = useState([]);

  // By default, will be a number
  const [editingStudentID, setEditingStudentID] = useState([null]);
  // By default, will be a string
  const [editingStudent, setEditingStudent] = useState("");

  useEffect(() => {
    fetch("http://localhost:5000/students")
      .then((response) => response.json())
      .then((data) => setStudents(data));
  }, []);

  // Creation of a method that allows us to create new students
  const addStudent = (firstName, lastName, dob, grade) => {
    fetch("http://localhost:5000/students", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ firstName, lastName, dob, grade }),
    })
      .then(response => response.json())
      // Setting current student to previous student
      .then(newStudent =>
        setStudents(prevStudents => [...prevStudents, newStudent])
      )
  }

  // Creation of a method that allows us to update existing students
  const updateStudent = (id, firstName, lastName, dob, grade) => {
    fetch(`http:localhost:5000/students/${id}`, {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ firstName, lastName, dob, grade }),
    }).then(() => {
      setStudents(prevStudents =>
        prevStudents.map(student =>
          student.id === id
            ? { ...student, firstName, lastName, dob, grade }
            : student
        )
      )
      // Resetting values to null/default values
      setEditingStudentID(null);
      setEditingStudent("");
    })
  }

  // Creation of a method that allows us to delete existing students
  const deleteStudent = (id) => {
    fetch(`http:localhost:5000/students/${id}`, {
      method: "DELETE",
    }).then(() => {
      setStudents(prevStudents =>
        prevStudents.filter(student => student.id !== id)
      )
    })
  }

  const handleSubmit = (e) => {
    // Prevent's the browser from using its default functions
    e.preventDefault();
    const firstName = e.target.firstName.value;
    const lastName = e.target.lastName.value;
    const dob = e.target.dob.value;
    const grade = e.target.grade.value;
    addStudent(firstName, lastName, dob, grade);
    // Clears the text boxes after a successful submission
    e.target.firstName.value = "";
    e.target.lastName.value = "";
    e.target.dob.value = "";
    e.target.grade.value = "";
  };

  return (
    <div className="container p-8 mt-14 mb-14 border rounded bg-white">
      <h1 className="text-2xl text-yellow-900 font-semibold mb-8 p-2 text-center border-2 border-yellow-600 rounded-lg bg-yellow-500 hover:bg-yellow-600">
        Currently Enrolled Students for 2023 Year
      </h1>
      <ul className="mt-4">
        {students.map((student) => (
          <li
            key={student.id}
            className="border border-gray-500 p-2 my-2 flex justify-between items-center bg-white rounded-lg hover:bg-gray-300"
          >
            {/* Checking to see if the Editing ID is equal to the post's current ID */}
            {editingStudentID === student.id ? (
              // If there IS an Editing ID
              <div className="flex items-center">
                <input
                  className="border p-1 m-2"
                  value={editingStudent}
                  // Updating the Editing firstName to what we have written above this line of code
                  onChange={(e) => setEditingStudent(e.target.value)}
                />
                {/* Creation of a button that allows us to save the changes to the student */}
                <button
                  className="bg-green-600 text-white py-1 px-2 ml-2 rounded-full hover:bg-green-700"
                  // Calling updatePost method and passing the post's ID and firstName as parameters
                  onClick={() => updateStudent(student.id, student.firstName, student.lastName, student.dob, student.grade, editingStudent)}
                >
                  Save
                </button>
              </div>
            ) : (
              // If there ISN'T an Editing ID (we will just display it)
              <div className="flex items-center">
                <span className="mr-2">{student.firstName}</span>
                <span className="mr-2">{student.lastName}</span>
                <span className="mr-2">{student.dob}</span>
                <span className="mr-2">{student.grade}</span>
                {/* Creation of a button that allows us to edit an existing student */}
                <button
                  className="bg-gray-500 text-white py-1 px-2 ml-2 rounded-full hover:bg-gray-600"
                  onClick={() => {
                    // Takes in all of the editing parameters
                    setEditingStudentID(student.id);
                    setEditingStudent(student.firstName);
                    setEditingStudent(student.lastName);
                    setEditingStudent(student.dob);
                    setEditingStudent(student.grade);
                  }}
                >
                  Edit
                </button>
                {/* Creation of a button that allows us to delete an existing student */}
                <button
                  className="bg-red-500 text-white py-1 px-2 ml-2 rounded-full hover:bg-red-600"
                  // Only requires the student's ID
                  onClick={() => deleteStudent(student.id)}
                >
                  Delete
                </button>
              </div>
            )}
          </li>
        ))}
      </ul>
      {/* Creation of a Registration Form for new students */}
      <div className="container mx-auto p-8 mt-14 border border-gray-500 rounded-lg bg-white mb-10">
        <h1 className="text-2xl font-semibold p-2 mx-auto text-center mb-8 border-2 border-emerald-600 text-emerald-800 bg-emerald-400 hover:bg-emerald-500 rounded-lg">
          New to NGHS? Register Now!
        </h1>
        {/* Calling of the submission method */}
        <form className="flex justify-between" onSubmit={handleSubmit}>
          <input
            className="border border-gray-500 rounded-lg p-2 mr-2 hover:bg-gray-300"
            type="text"
            name="firstName"
            placeholder="First Name.."
          />
          <input
            className="border border-gray-500 rounded-lg p-2 mr-2 hover:bg-gray-300"
            type="text"
            name="lastName"
            placeholder="Last Name.."
          />
          <input
            className="border border-gray-500 rounded-lg p-2 mr-2 hover:bg-gray-300"
            type="text"
            name="dob"
            placeholder="Date of Birth.."
          />
          <input
            className="border border-gray-500 rounded-lg p-2 mr-2 hover:bg-gray-300"
            type="text"
            name="grade"
            placeholder="Current Grade.."
          />
          <button
            className="bg-blue-500 text-white px-2 rounded hover:bg-blue-600"
            type="submit"
          >
            Add Student
          </button>
        </form>
      </div>
    </div>
  );
};

export default StudentDatabase;
