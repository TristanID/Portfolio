/**
 * Group 7: Project Phase 4: Building the App
 * CPRG-303-G: Mobile Application Development
 * Created by: Tristan Idolor, Jaskaran Sran, Tyson Harder, Troy Franks
 */

import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, Switch } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import Home from "./screens/HomeScreen";
import Calculator from "./screens/CalculatorScreen";
import Output from "./screens/OutputScreen";
import { useColorScheme } from "nativewind";

const Stack = createStackNavigator();

export default function App() {
  const { colorScheme, toggleColorScheme } = useColorScheme();
  
  return (
    <NavigationContainer>
      <Stack.Navigator>

        <Stack.Screen name="Home" component={Home}
          options={{
            title: "",
            headerStyle: { backgroundColor: "#0000ff" },
            headerTintColor: "white",
            headerTitleStyle: { fontWeight: "bold" },
          }}/>

        <Stack.Screen name="Calculator" component={Calculator}
          options={{
            title: "",
            title: "A Really Good Calculator",
            headerStyle: { backgroundColor: "#0000ff" },
            headerTintColor: "white",
            headerTitleStyle: { fontWeight: "bold" },
            headerTitleAlign: "center",
          }}/>

          <Stack.Screen name="Output" component={Output}
          options={{
            title: "",
            title:"A Really Good Calculator",
            headerStyle: { backgroundColor: "#0000ff" },
            headerTintColor: "white",
            headerTitleStyle: { fontWeight: "bold" },
            headerTitleAlign: "center",
          }}/>
          
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});

{
  /* <style>
        body {
            background-color: #222;
            color: #fff;
            font-family: Arial, sans-serif;
            text-align: center;
        }
        .enter-box {
            position: fixed;
            bottom: 200px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #0000ff;
            color: #fff;
            padding: 10px 20px;
            border-radius: 10px;
            cursor: pointer;
            padding-top:10px;
            padding-bottom:10px;
            padding-left:20px;
            padding-right:20px;
        }
        .enter-box:hover {
            background-color:#00008b;
        }
        .brand {
            padding-top: 315px;
            text-align: center;
            font-size: 36px;
            flex-grow: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style> */
}
