/**
 * Group 7: Project Phase 4: Building the App
 * CPRG-303-G: Mobile Application Development
 * Created by: Tristan Idolor, Jaskaran Sran, Tyson Harder, Troy Franks
 */

import React from 'react';
import { View, StyleSheet } from 'react-native';
import Footer from "../components/Footer";

const MainLayout = ({ children }) => {
  return (
    <View style={styles.container}>
      {children}
      {/* <Footer /> */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default MainLayout;