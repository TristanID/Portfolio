/**
 * Group 7: Project Phase 4: Building the App
 * CPRG-303-G: Mobile Application Development
 * Created by: Tristan Idolor, Jaskaran Sran, Tyson Harder, Troy Franks
 */

import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
  StyleSheet,
  View,
  Text,
  Pressable,
  TouchableOpacity,
  Switch,
} from "react-native";
import { useColorScheme } from "nativewind";
import MainLayout from "../layouts/MainLayout";

export default function App({ navigation }) {
  const { colorScheme, toggleColorScheme } = useColorScheme();
  const [expression, setExpression] = useState("");

  const handleButtonPress = (value) => {
    setExpression((prevExpression) => prevExpression + value);
  };

  // const handleEvaluate = () => {
  //   try {
  //     const result = eval(expression);
  //     navigation.navigate("Output", { result: result.toString() });
  //   } catch (error) {
  //     setExpression("Error");
  //   }
  // };

  // const handleEvaluate = () => {
  //   let processedExpression = expression.replace(/√/g, 'Math.sqrt');
  //   processedExpression = processedExpression.replace(/÷/g, '/');
  
  //   try {
  //     const result = eval(processedExpression);
  //     navigation.navigate("Output", { result: result.toString() });
  //   } catch (error) {
  //     setExpression("Error");
  //   }
  // };

  // const handleEvaluate = () => {
  //   let processedExpression = expression.replace(/√/g, 'Math.sqrt');
  
  //   try {
  //     const result = evaluateExpression(processedExpression);
  //     navigation.navigate("Output", { result: result.toString() });
  //   } catch (error) {
  //     setExpression("Error");
  //   }
  // };
  
  // const evaluateExpression = (expression) => {
  //   const tokens = expression.split(/(\+|\-|\*|\/)/);
  //   let result = null;
  //   let currentOperator = null;
  
  //   tokens.forEach((token) => {
  //     if (token === '+' || token === '-' || token === '*' || token === '/') {
  //       currentOperator = token;
  //     } else {
  //       const value = token.includes('Math.sqrt') ? handleSquareRoot(token) : parseFloat(token);
  //       if (result === null) {
  //         result = value;
  //       } else {
  //         switch (currentOperator) {
  //           case '+':
  //             result += value;
  //             break;
  //           case '-':
  //             result -= value;
  //             break;
  //           case '*':
  //             result *= value;
  //             break;
  //           case '/':
  //             result /= value;
  //             break;
  //           default:
  //             break;
  //         }
  //       }
  //     }
  //   });
  
  //   return result;
  // };
  
  // const handleSquareRoot = (token) => {
  //   const valueToRoot = parseFloat(token.substring(9, token.length - 1)); // Extract the value inside Math.sqrt()
  //   return Math.sqrt(valueToRoot);
  // };

  // const handleSquareRoot = (token) => {
  //   const valueToRoot = parseFloat(token.substring(1)); // Remove the √ symbol and parse the value
  //   return Math.sqrt(valueToRoot);
  // };

  const handleEvaluate = () => {
    let processedExpression = expression.replace(/√/g, 'Math.sqrt');
    processedExpression = processedExpression.replace(/÷/g, '/');
  
    try {
      const result = evaluateExpression(processedExpression);
      navigation.navigate("Output", { result: result.toString() });
    } catch (error) {
      setExpression("Error");
    }
  };
  
  const evaluateExpression = (expression) => {
    const tokens = expression.split(/(\+|\-|\*|\/)/);
    let result = null;
    let currentOperator = null;
  
    tokens.forEach((token) => {
      if (token === '+' || token === '-' || token === '*' || token === '/') {
        currentOperator = token;
      } else {
        const value = token.includes('Math.sqrt') ? handleSquareRoot(token) : parseFloat(token);
        if (result === null) {
          result = value;
        } else {
          switch (currentOperator) {
            case '+':
              result += value;
              break;
            case '-':
              result -= value;
              break;
            case '*':
              result *= value;
              break;
            case '/':
              result /= value;
              break;
            default:
              break;
          }
        }
      }
    });
  
    return result;
  };
  
  const handleSquareRoot = (token) => {
    const valueToRoot = parseFloat(token.substring(9)); // Remove 'Math.sqrt' and parse the value
    return Math.sqrt(valueToRoot);
  };

  const handleClear = () => {
    setExpression("");
  };

  return (
    <MainLayout>
      <View style={colorScheme == "light" ? styles.textWhite : styles.textBlack}>
        <StatusBar style={colorScheme === "dark" ? "dark" : "light"} />

        <View style={styles.toggleContainer}>
          <Switch value={colorScheme == "dark"} onChange={toggleColorScheme} />
        </View>

        <View style={styles.answer}>
          <Pressable style={styles.bigSqr}>
            <Text style={styles.bigText}>{expression}</Text>
          </Pressable>
        </View>

        <View style={styles.buttonsContainer}>
          <View style={styles.buttonsRow}>
            <Pressable
              style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
              onPress={() => handleButtonPress("√")}>
              <Text style={styles.text}>√</Text>
            </Pressable>
            <Pressable
              style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
              onPress={() => handleButtonPress("+")}>
              <Text style={styles.text}>+</Text>
            </Pressable>
            <Pressable
              style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
              onPress={() => handleButtonPress("-")}>
              <Text style={styles.text}>−</Text>
            </Pressable>
            <Pressable
              style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
              onPress={() => handleButtonPress("*")}>
              <Text style={styles.text}>×</Text>
            </Pressable>
          </View>
        </View>

        <View style={styles.buttonsRow}>
          <Pressable
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => handleButtonPress("7")}>
            <Text style={styles.text}>7</Text>
          </Pressable>
          <Pressable
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => handleButtonPress("8")}>
            <Text style={styles.text}>8</Text>
          </Pressable>
          <Pressable
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => handleButtonPress("9")}>
            <Text style={styles.text}>9</Text>
          </Pressable>
          <Pressable
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => handleButtonPress("÷")}>
            <Text style={styles.text}>÷</Text>
          </Pressable>
        </View>

        <View style={styles.buttonsRow}>
          <Pressable
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => handleButtonPress("4")}>
            <Text style={styles.text}>4</Text>
          </Pressable>
          <Pressable
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => handleButtonPress("5")}>
            <Text style={styles.text}>5</Text>
          </Pressable>
          <Pressable
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => handleButtonPress("6")}>
            <Text style={styles.text}>6</Text>
          </Pressable>
          <Pressable
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => handleButtonPress(".")}>
            <Text style={styles.text}>.</Text>
          </Pressable>
        </View>

        <View style={styles.buttonsRow}>
          <Pressable
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => handleButtonPress("1")}>
            <Text style={styles.text}>1</Text>
          </Pressable>
          <Pressable
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => handleButtonPress("2")}>
            <Text style={styles.text}>2</Text>
          </Pressable>
          <Pressable
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => handleButtonPress("3")}>
            <Text style={styles.text}>3</Text>
          </Pressable>
          <TouchableOpacity
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack ]}
            onPress={() => {
            handleEvaluate();}}>
            <Text style={styles.text}>=</Text>
          </TouchableOpacity>
          </View>

        <View style={styles.buttonsRow}>
          <Pressable
            style={[colorScheme === "light" ? styles.ACButtonWhite : styles.ACButtonBlack]}
            onPress={handleClear}>
            <Text style={styles.text}>AC</Text>
          </Pressable>
          <Pressable
            style={[colorScheme === "light" ? styles.bottomButtonWhite : styles.bottomButtonBlack]}
            onPress={() => handleButtonPress("0")}>
            <Text style={styles.text}>0</Text>
          </Pressable>
        </View>

      </View>
    </MainLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#222",
    padding: 8,
    flexDirection: "column",
    alignItems: "center",
    // flexDirection: "row",
    // justifyContent: "column-reverse",

    // justifyContent --> horizontal axis
    // alignItems --> vertical axis
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
    marginTop: 10,
    color: "white",
  },
  buttonsContainer: {
    marginTop: 2,
  },
  buttonsRow: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
  },
  sqr: {
    backgroundColor: "#0000ff",
    width: 90,
    height: 60,
    margin: 5,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  bottomSqr: {
    backgroundColor: "#0000ff",
    width: 190,
    height: 60,
    margin: 5,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  answer: {
    marginTop: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  bigText: {
    fontSize: 20,
    fontWeight: "bold",
  },
  text: {
    fontSize: 20,
    color: "white",
  },
  bigSqr: {
    marginBottom: 60,
    backgroundColor: "white",
    paddingHorizontal: 140,
    paddingVertical: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: "black",
  },
  buttonWhite: {
    backgroundColor: "#0000ff",
    marginTop: 6,
    padding: 8,
    borderRadius: 10,
    width: 90,
    height: 60,
    margin: 5,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonBlack: {
    backgroundColor: "gray",
    marginTop: 6,
    padding: 8,
    borderRadius: 10,
    width: 90,
    height: 60,
    margin: 5,
    justifyContent: "center",
    alignItems: "center",
  },
  bottomButtonBlack: {
    backgroundColor: "#0000ff",
    width: 190,
    height: 60,
    margin: 5,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  bottomButtonWhite: {
    backgroundColor: "gray",
    width: 190,
    height: 60,
    margin: 5,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  ACButtonBlack: {
    backgroundColor: "orange",
    width: 190,
    height: 60,
    margin: 5,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  ACButtonWhite: {
    backgroundColor: "#333333",
    width: 190,
    height: 60,
    margin: 5,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  textBlack: {
    color: "white",
    backgroundColor: "#222222",
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  textWhite: {
    color: "black",
    backgroundColor: "white",
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});
