/**
 * Group 7: Project Phase 4: Building the App
 * CPRG-303-G: Mobile Application Development
 * Created by: Tristan Idolor, Jaskaran Sran, Tyson Harder, Troy Franks
 */

import { StatusBar } from "expo-status-bar";
import { StyleSheet, View, Text, TouchableOpacity, Switch } from "react-native";
import { useColorScheme } from "nativewind";
import MainLayout from "../layouts/MainLayout";

export default function App({ navigation }) {
  const { colorScheme, toggleColorScheme } = useColorScheme();

  return (
    <MainLayout>
      <View style={colorScheme == "light" ? styles.textWhite : styles.textBlack}>
        <StatusBar style={colorScheme === "dark" ? "dark" : "light"} />

        <View style={styles.toggleContainer}>
          <Switch value={colorScheme == "dark"} onChange={toggleColorScheme} />
        </View>

        <Text style={colorScheme === "light" ? styles.titleWhite : styles.titleBlack}>
          Welcome to A Really Good Calculator
        </Text>
        
        {/* <View>
          <TouchableOpacity
            style={[styles.button, styles.buttonWidth]}
            onPress={() => navigation.navigate("Calculator")}>
            <Text style={styles.buttonText}>Enter</Text>
          </TouchableOpacity>
        </View> */}

        {/* onPress event navigates the user to the Calculator page */}
        <View>
          <TouchableOpacity
            style={[colorScheme === "dark" ? styles.buttonWhite : styles.buttonBlack]}
            onPress={() => navigation.navigate("Calculator")}>
            <Text style={[colorScheme === "dark" ? styles.toggleButtonWhite : styles.toggleButtonBlack]}>
              Enter
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.subTextContainer}>
          <Text style={colorScheme === "light" ? styles.textWhite : styles.textBlack}>
            Created by:
          </Text>
          <Text style={colorScheme === "light" ? styles.textWhite : styles.textBlack}>
            Jaskaran Sran, Tristan Idolor, Tyson Harder, Troy Franks
          </Text>
        </View>
        
      </View>
    </MainLayout>
  );
}

const styles = StyleSheet.create({
  // container: {
  //   flex: 1,
  //   backgroundColor: "#222222",
  //   alignItems: "center",
  //   justifyContent: "center",
  //   position: "relative",
  // },
  toggleContainer: {
    position: "absolute",
    top: 0,
    // width: "100%",
    // alignItems: "center",
  },
  // text: {
  //   fontSize: 30,
  //   fontWeight: "bold",
  //   marginBottom: 36,
  //   marginTop: 40,
  //   color: "white",
  // },
  // button: {
  //   backgroundColor: "#0000ff",
  //   padding: 8,
  //   borderRadius: 10,
  //   marginTop: 30,
  // },
  toggleButtonBlack: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  toggleButtonWhite: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  buttonWidth: {
    width: 120,
  },
  subTextContainer: {
    position: "absolute",
    bottom: 0,
    // width: "100%",
    alignItems: "center",
    paddingBottom: 4,
  },
  // subText: {
  //   fontSize: 12,
  //   color: "white",
  //   marginBottom: 5,
  // },
  buttonBlack: {
    backgroundColor: "#0000ff",
    marginTop: 6,
    padding: 12,
    borderRadius: 10,
    width: 140,
  },
  buttonWhite: {
    backgroundColor: "#333333",
    marginTop: 6,
    padding: 12,
    borderRadius: 10,
    width: 140,
  },
  textBlack: {
    color: "white",
    backgroundColor: "#222222",
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  textWhite: {
    color: "black",
    backgroundColor: "white",
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  titleBlack: {
    color: "white",
    backgroundColor: "#222222",
    marginBottom: 80,
    fontSize: 20,
    fontWeight: "bold",
  },
  titleWhite: {
    color: "black",
    backgroundColor: "white",
    marginBottom: 80,
    fontSize: 20,
    fontWeight: "bold",
  },
});
