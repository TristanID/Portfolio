/**
 * Group 7: Project Phase 4: Building the App
 * CPRG-303-G: Mobile Application Development
 * Created by: Tristan Idolor, Jaskaran Sran, Tyson Harder, Troy Franks
 */

import { React, useState } from "react";
import { StyleSheet, View, Text, TouchableOpacity, Switch } from "react-native";
import { useColorScheme } from "nativewind";
import MainLayout from "../layouts/MainLayout";
import { StatusBar } from "expo-status-bar";

export default function App({ navigation, route }) {
  const { colorScheme, toggleColorScheme } = useColorScheme();
  const { result } = route.params || {};

  return (
    <MainLayout>
      <View style={colorScheme == "light" ? styles.textWhite : styles.textBlack}>
        <StatusBar style={colorScheme === "dark" ? "dark" : "light"} />

        <View style={styles.toggleContainer}>
          <Switch value={colorScheme == "dark"} onChange={toggleColorScheme} />
        </View>

        <Text style={colorScheme === "light" ? styles.titleWhite : styles.titleBlack}>
          The answer to your calculation is:
        </Text>

        <View style={styles.sqr}>
          <Text style={styles.answer}>{result}</Text>
        </View>

        {/* onPress event navigates the user back to the Calculator page */}
        <TouchableOpacity
          style={[colorScheme === "light" ? styles.buttonWhite : styles.buttonBlack]}
          onPress={() => navigation.navigate("Calculator")}>
          <Text style={styles.buttonText}>New Calculation</Text>
        </TouchableOpacity>

      </View>
    </MainLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // backgroundColor: "#222222",
    alignItems: "center",
    justifyContent: "center",
    // marginBottom: 40,
  },
  text: {
    fontSize: 30,
    fontWeight: "bold",
    marginBottom: 30,
    marginTop: 40,
    color: "white",
    paddingBottom: 26,
  },
  // button: {
  //   backgroundColor: "#0000ff",
  //   padding: 10,
  //   borderRadius: 10,
  //   marginTop: 60,
  // },
  toggleButtonBlack: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  toggleButtonWhite: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  buttonWidth: {
    width: 150,
  },
  buttonBlack: {
    backgroundColor: "#0000ff",
    marginTop: 6,
    padding: 10,
    borderRadius: 10,
    width: 120,
    marginTop: 60,
  },
  buttonWhite: {
    backgroundColor: "#333333",
    marginTop: 6,
    padding: 10,
    borderRadius: 10,
    width: 120,
    marginTop: 60,
  },
  sqr: {
    backgroundColor: "white",
    borderRadius: 10,
    paddingHorizontal: 140,
    paddingVertical: 20,
    borderWidth: 2,
    borderColor: "black",
  },
  answer: {
    fontSize: 20,
    fontWeight: "bold",
  },
  toggleContainer: {
    position: "absolute",
    top: 0,
    // width: "100%",
  },
  textBlack: {
    color: "white",
    backgroundColor: "#222222",
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  textWhite: {
    color: "black",
    backgroundColor: "white",
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  titleBlack: {
    color: "white",
    backgroundColor: "#222222",
    marginBottom: 40,
    fontSize: 16,
  },
  titleWhite: {
    color: "black",
    backgroundColor: "white",
    marginBottom: 40,
    fontSize: 16,
  },
});
